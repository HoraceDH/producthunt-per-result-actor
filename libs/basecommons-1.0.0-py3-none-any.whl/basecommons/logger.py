#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-06-15 22:25.
# @author Horace
import logging
import os
import sys
from logging.handlers import TimedRotatingFileHandler

LOGS_DIR = "logs"
date_fmt = "%Y-%m-%d %H:%M:%S"
logger_fmt = "%(asctime)s.%(msecs)03d %(levelname)s [%(threadName)s]%(filename)s:%(lineno)d %(name)s - %(message)s"


class ConsoleFormatter(logging.Formatter):
    """Custom formatter that adds colors to log levels"""

    grey = "\x1b[38;20m"
    yellow = "\x1b[33;20m"
    red = "\x1b[31;20m"
    bold_red = "\x1b[31;1m"
    blue = "\x1b[34;20m"
    green = "\x1b[32;20m"
    reset = "\x1b[0m"

    FORMATS = {
        logging.DEBUG: blue + logger_fmt + reset,
        logging.INFO: green + logger_fmt + reset,
        logging.WARNING: yellow + logger_fmt + reset,
        logging.ERROR: red + logger_fmt + reset,
        logging.CRITICAL: bold_red + logger_fmt + reset
    }

    def format(self, record):
        log_fmt = self.FORMATS.get(record.levelno)
        formatter = logging.Formatter(log_fmt, datefmt=date_fmt)
        return formatter.format(record)


def init_logging(level=logging.DEBUG, console=True):
    """初始化日志记录"""

    root_logger = logging.getLogger()
    root_logger.propagate = False
    root_logger.setLevel(level)
    os.makedirs(LOGS_DIR, exist_ok=True)

    if console:
        # Configure stream handler (console output) with color formatter
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(level)
        console_handler.setFormatter(ConsoleFormatter())
        console_handler.setLevel(int(os.environ.get("CONSOLE_LOG_LEVEL", 60)))
        root_logger.addHandler(console_handler)

    if level == logging.DEBUG:
        # debug.log 配置
        debug_file_handler = TimedRotatingFileHandler(
            os.path.join(LOGS_DIR, "debug.log"),
            when="H",  # 每小时
            interval=1,  # 间隔1小时
            backupCount=24 * 7,  # 保留7天的日志
            encoding="utf-8"
        )
        debug_file_handler.setFormatter(logging.Formatter(logger_fmt, datefmt=date_fmt))
        debug_file_handler.setLevel(logging.DEBUG)
        root_logger.addHandler(debug_file_handler)

    # app.log 配置
    app_file_handler = TimedRotatingFileHandler(
        os.path.join(LOGS_DIR, "app.log"),
        when="H",  # 每小时
        interval=1,  # 间隔1小时
        backupCount=24 * 7,  # 保留7天的日志
        encoding="utf-8"
    )
    app_file_handler.setFormatter(logging.Formatter(logger_fmt, datefmt=date_fmt))
    app_file_handler.setLevel(logging.INFO)
    root_logger.addHandler(app_file_handler)

    # error.log 配置
    error_file_handler = TimedRotatingFileHandler(
        os.path.join(LOGS_DIR, "error.log"),
        when="H",  # 每小时
        interval=1,  # 间隔1小时
        backupCount=24 * 7,  # 保留7天的日志
        encoding="utf-8"
    )
    error_file_handler.setFormatter(logging.Formatter(logger_fmt, datefmt=date_fmt))
    error_file_handler.setLevel(logging.WARNING)
    root_logger.addHandler(error_file_handler)

    # Get comma-separated list of loggers to suppress from env
    suppress_loggers = os.getenv("SUPPRESS_LOGGERS", "").strip()
    if suppress_loggers:
        for logger_name in suppress_loggers.split(","):
            logger_name = logger_name.strip()
            if logger_name:
                logging.getLogger(logger_name).setLevel(logging.CRITICAL)

    logging.info(f"logging configured with level: {logging.getLevelName(level)}")

if __name__ == '__main__':
    init_logging(level=logging.DEBUG, console=True)
    print("hello world console message")
    logging.debug("This is a debug message")
    logging.info("Hello, world!")
    logging.warning("This is a warning message")
    logging.error("This is an error message")
    logging.critical("This is a critical message")