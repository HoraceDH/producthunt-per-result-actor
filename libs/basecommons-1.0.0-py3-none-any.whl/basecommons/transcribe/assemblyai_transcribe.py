#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-11-07 11:51.
# @author Horace

import logging
import os
import time
import traceback

import assemblyai

from basecommons.logger import init_logging
from basecommons.utils.json_utils import to_json_string

logger = logging.getLogger(__name__)


class AssemblyaiTranscribe:
    """
    基于AssemblyAI的语音转写器
    """

    def __init__(self, api_key: str = None, custom_logger: logging.Logger = None):
        """
        初始化音频转录服务
        :param api_key: AssemblyAI API Key，如果不提供则从环境变量读取
        """
        self.logger = custom_logger or logger
        self.api_key = api_key or os.getenv("ASSEMBLY_AI_KEY")
        if not self.api_key:
            raise ValueError("AssemblyAI API Key is required. Set ASSEMBLY_AI_KEY environment variable or pass api_key parameter.")

        # 设置 AssemblyAI API Key
        assemblyai.settings.api_key = self.api_key
        self.transcriber = assemblyai.Transcriber()

    def transcribe(self, url: str, language_code: str = None, delete_audio: bool = True) -> dict:
        """
        转录音频文件
        :param url: 音频文件路径或者是URL
        :param language_code: 音频语言代码（可选）默认自动检测，例如：'en', 'zh'
        :param delete_audio: 是否在转录完成后删除音频文件（默认True）
        :return: 转录结果字典
        """
        start_time = time.time()
        try:
            logger.info(f"start transcribing, language_code: {language_code}, url: {url}")

            # 配置转录选项
            config = assemblyai.TranscriptionConfig(
                speaker_labels=True,  # 启用说话人分离
                language_code=language_code,  # 语言代码
                speech_model=assemblyai.SpeechModel.best,  # 使用最强模型（付费）
                punctuate=True,  # 自动标点
                format_text=True,  # 格式化文本
            )

            # 执行转录
            transcript = self.transcriber.transcribe(url, config=config)

            # 检查错误
            if transcript.error:
                self.logger.error(f"transcription error, language_code: {language_code}, url: {url}, error: {transcript.error}, trace: {traceback.format_exc()}")
                return None

            # 构建结果
            result = {
                "id": transcript.id,
                "text": transcript.text,
                "status": transcript.status.value,
                "language_code": transcript.json_response.get("language_code"),
                "audio_duration": transcript.audio_duration,
                # "words": transcript.words,
            }

            # 如果启用了说话人分离，添加分段信息
            if transcript.utterances:
                segments = []
                for utterance in transcript.utterances:
                    segments.append({
                        "speaker": utterance.speaker,
                        "text": utterance.text,
                        "start": utterance.start,
                        "end": utterance.end,
                        "confidence": utterance.confidence,
                        # "words": utterance.words,
                    })
                result["segments"] = segments

                # 统计说话人
                speakers = set(seg["speaker"] for seg in segments)
                result["speaker_count"] = len(speakers)

            # 如果是文件而不是url地址，则删除文件
            if delete_audio and os.path.isfile(url):
                os.remove(url)

            logger.info(
                f"transcribe success, use_time: {time.time() - start_time:.2f} seconds, delete_audio: {delete_audio}, language_code: {language_code}, speaker_count: {result["speaker_count"]}, text_length: {len(result['text'])}, url: {url}")
            return result
        except Exception as e:
            self.logger.error(f"failed to transcribe, use_time: {time.time() - start_time:.2f} seconds, language_code: {language_code}, url: {url}, error: {e}, trace: {traceback.format_exc()}")
            return None


if __name__ == '__main__':
    init_logging()
    assemblyai_transcribe = AssemblyaiTranscribe()
    result = assemblyai_transcribe.transcribe("/var/folders/z_/t1yrk8b51435btxqcxw1mz1r0000gn/T/youtube_downloads/None.mp3")
    logger.info(f"transcribe result: {to_json_string(result)}")
