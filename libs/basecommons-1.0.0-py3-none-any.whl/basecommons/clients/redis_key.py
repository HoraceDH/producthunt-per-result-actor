#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-06-20 10:14.
# @author Horace
import logging

logger = logging.getLogger(__name__)

g_redis_key_prefix = "template"


def get_audio_bytes_key(unique_id):
    """
    获取音频字节的key
    :param unique_id: 唯一ID
    :return: 音频字节的key
    """
    return f"{g_redis_key_prefix}:realtime:transcribe:audio_bytes:{unique_id}"


def get_audio_bytes_start_key(unique_id):
    """
    存储处理音频字节开始位置的key
    :param unique_id: 唯一ID
    :return: 音频字节开始位置的key
    """
    return f"{g_redis_key_prefix}:realtime:transcribe:audio_bytes:start:{unique_id}"


def get_lock_key(lock_name):
    """
    获取转录锁的key
    :param lock_name: 锁的名称
    :return: 锁的key
    """
    return f"{g_redis_key_prefix}:lock:{lock_name}"
