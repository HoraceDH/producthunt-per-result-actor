#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-10-20 10:21.
# @author Horace
import logging

from basecommons.clients.http_client import HttpClient, DefaultRetryStrategy
from basecommons.logger import init_logging

logger = logging.getLogger(__name__)
if __name__ == '__main__':
    init_logging()
    http_client = HttpClient(retry_strategy=DefaultRetryStrategy(max_retries=5, base_delay=1.0, retry_on_contains_text="too many requests"))
    result = http_client.post("http://localhost:1577/api/user/getById", body={"userId": 1})
    logger.info(f"get user by id result: {result.text}")
