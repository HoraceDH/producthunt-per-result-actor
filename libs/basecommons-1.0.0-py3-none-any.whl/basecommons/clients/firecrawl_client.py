#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-08-14 14:57.
# @author Horace
import logging
import os
from typing import Any

from firecrawl import FirecrawlApp
from firecrawl.firecrawl import ScrapeResponse

logger = logging.getLogger(__name__)

G_ENV_FIRECRAWL_API_KEY = os.environ.get("FIRECRAWL_API_KEY", "")
app = FirecrawlApp(api_key=G_ENV_FIRECRAWL_API_KEY)


def crawler_url_content(url: str, timeout: int = 120000) -> ScrapeResponse[Any]:
    """
    爬取url并获得文本内容
    :param url: URL地址
    :return:
    """

    try:
        llm_extraction_result = app.scrape_url(url=url, formats=["markdown"], only_main_content=True, timeout=timeout)
        return llm_extraction_result
    except Exception as e:
        logger.error(f"crawler url error, url: {url}, error: {e}")
        return None


if __name__ == '__main__':
    result = crawler_url_content("https://www.google.com")
    print(result)
