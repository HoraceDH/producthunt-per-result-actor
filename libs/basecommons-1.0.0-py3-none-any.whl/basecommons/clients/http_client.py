#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-08-06 17:52.
# @author Horace
import logging
import traceback
from abc import ABC, abstractmethod

from basecommons.utils.json_utils import to_json_string

g_logger = logging.getLogger(__name__)
import httpx
import asyncio
from typing import List, Optional, Dict, Any, Callable, Awaitable


class Interceptor:
    """
    拦截器基类：用于请求前后逻辑，如日志、鉴权、监控等
    """

    def before_request(self, method: str, url: str, **kwargs):
        pass

    def after_response(self, method: str, url: str, response: Optional[httpx.Response] = None, exception: Optional[Exception] = None):
        pass


class RetryStrategy(ABC):
    """
    重试策略接口：用于决定是否应该重试请求
    """

    @abstractmethod
    def should_retry(self, attempt: int, method: str, url: str,
                     response: Optional[httpx.Response] = None,
                     exception: Optional[Exception] = None) -> tuple[bool, Optional[str]]:
        """
        判断是否应该重试请求

        :param attempt: 当前重试次数（从0开始）
        :param method: 请求方法
        :param url: 请求URL
        :param response: 响应对象，如果请求失败则为None
        :param exception: 异常对象，如果请求成功则为None
        :return: 是否应该重试, 重试原因
        """
        pass

    @abstractmethod
    def get_retry_delay(self, attempt: int) -> float:
        """
        获取重试延迟时间（秒）

        :param attempt: 当前重试次数（从0开始）
        :return: 延迟时间（秒）
        """
        pass


class NoneRetryStrategy(RetryStrategy):
    """
    不重试策略实现
    """

    def should_retry(self, attempt: int, method: str, url: str,
                     response: Optional[httpx.Response] = None,
                     exception: Optional[Exception] = None) -> tuple[bool, Optional[str]]:
        return False, None

    def get_retry_delay(self, attempt: int) -> float:
        return 100.0


class DefaultRetryStrategy(RetryStrategy):
    """
    默认重试策略实现
    """

    def __init__(self, max_retries: int = 3, base_delay: float = 1.0, max_delay: float = 10.0,
                 retry_on_status_codes: Optional[List[int]] = None,
                 retry_on_contains_text: str = "too many requests"):
        """
        初始化默认重试策略

        :param max_retries: 最大重试次数
        :param base_delay: 基础延迟时间（秒）
        :param max_delay: 最大延迟时间（秒）
        :param retry_on_status_codes: 需要重试的HTTP状态码列表
        :param retry_on_contains_text: 响应文本中包含指定字符串则重试
        """
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.retry_on_status_codes = retry_on_status_codes or [429, 500, 502, 503, 504]
        self.retry_on_contains_text = retry_on_contains_text

    def should_retry(self, attempt: int, method: str, url: str,
                     response: Optional[httpx.Response] = None,
                     exception: Optional[Exception] = None) -> bool:
        # 检查是否超过最大重试次数
        if attempt >= self.max_retries:
            return False, None

        # 检查响应情况
        if response is not None:
            # 检查状态码
            if response.status_code in self.retry_on_status_codes:
                return True, f"HTTP status code {response.status_code}"

            # 检查响应文本中是否包含指定字符串
            if self.retry_on_contains_text and self.retry_on_contains_text.lower() in response.text.lower():
                return True, f"Response contains '{self.retry_on_contains_text}'"

        # 检查异常情况
        if exception is not None:
            # 如果状态码是404，则不需要重试
            if response is not None and response.status_code == 404:
                return False, None

            if hasattr(exception, "response"):
                exception_response = exception.response
                if hasattr(exception_response, "status_code") and exception_response.status_code == 404:
                    return False, None

            # 网络异常、超时等可以重试
            if isinstance(exception, httpx.NetworkError):
                return True, f"Network error: {str(exception)}"
            if isinstance(exception, httpx.TimeoutException):
                return True, f"Timeout error: {str(exception)}"
            return True, f"Other error: {str(exception)}"

        return False, None

    def get_retry_delay(self, attempt: int) -> float:
        # 指数退避算法：base_delay * (2 ** attempt)
        delay = self.base_delay * (2 ** attempt)
        # 不超过最大延迟时间
        return min(delay, self.max_delay)


class HttpClient:
    """
    通用 HTTP 客户端封装类，支持：
    - 同步 / 异步请求
    - Cookie 管理（自动 + 手动）
    - 请求拦截器机制
    - 连接池 / 超时设置
    """

    def __init__(self,
                 timeout_seconds: float = 40.0,
                 connect_timeout_seconds: float = 20.0,
                 max_connections: int = 200,
                 max_keepalive_connections: int = 10,
                 headers: Optional[Dict[str, str]] = None,
                 interceptors: Optional[List[Interceptor]] = None,
                 retry_strategy: Optional[RetryStrategy] = None,
                 logger: Optional[logging.Logger] = None,
                 error_print_details: bool = False,
                 httpx_logger_level: int = logging.WARNING,
                 ):
        """
        初始化客户端配置
        :param timeout_seconds: 请求总超时时间
        :param connect_timeout_seconds: 建立连接超时时间
        :param max_connections: 最大连接数
        :param max_keepalive_connections: 最大长连接数
        :param headers: 默认请求头
        :param interceptors: 拦截器列表
        :param retry_strategy: 重试策略
        :param logger: 日志记录器
        :param error_print_details: 错误时，是否详细日志
        :param httpx_logger_level: httpx 日志级别
        """
        logging.getLogger("httpx").setLevel(httpx_logger_level)
        self.logger = logger if logger is not None else g_logger
        self.error_print_details = error_print_details
        self.timeout = httpx.Timeout(timeout_seconds, connect=connect_timeout_seconds)
        self.limits = httpx.Limits(
            max_connections=max_connections,
            max_keepalive_connections=max_keepalive_connections,
        )
        self.headers = headers or {}
        self.interceptors = interceptors or []
        self.retry_strategy = retry_strategy or NoneRetryStrategy()

        self._client = httpx.Client(
            timeout=self.timeout,
            limits=self.limits,
            headers=self.headers,
        )

        self._async_client = httpx.AsyncClient(
            timeout=self.timeout,
            limits=self.limits,
            headers=self.headers,
            cookies=httpx.Cookies()
        )

    def close(self):
        """
        关闭客户端连接池，释放资源
        """
        self._client.close()
        asyncio.run(self._async_client.aclose())

    def _call_interceptors_before(self, method: str, url: str, **kwargs):
        """
        拦截器钩子：在请求前调用
        :param method: 请求方法
        :param url: 请求地址
        :param kwargs: 请求参数
        :return:
        """
        for interceptor in self.interceptors:
            interceptor.before_request(method, url, **kwargs)

    def _call_interceptors_after(self, method: str, url: str, response=None, exception=None):
        """
        拦截器钩子：在请求后调用
        :param method: 请求方法
        :param url: 请求地址
        :param response: 响应对象
        :param exception: 异常对象
        :return:
        """
        for interceptor in self.interceptors:
            interceptor.after_response(method, url, response=response, exception=exception)

    def _get_url(self, url: str = None, response: httpx.Response = None):
        """
        获取响应的URL
        :param url: 请求地址
        :param response: 响应对象
        :return:
        """
        if self.error_print_details:
            return url if url else response.url
        return ""

    def _raise_for_status(self, response: httpx.Response, params: Optional[Dict[str, Any]] = None, form_data: Any = None, body: Any = None):
        """
        检查响应状态码是否成功，否则抛出异常
        :param response: 响应对象
        :param params: 请求参数
        :param form_data: 请求数据
        :return:
        """
        if response.status_code != 200:
            if self.error_print_details:
                msg = f"http request error, code: {response.status_code}, params: {params}, data: {form_data}, body: {body}, url: {self._get_url(response=response)}, headers: {to_json_string(dict(response.headers))}, response_text: {response.text}, trace: {traceback.format_exc()}"
                self.logger.error(msg)
                raise httpx.HTTPStatusError(msg, request=response.request, response=response)
            else:
                raise httpx.HTTPStatusError(f"request error, code: {response.status_code}", request=response.request, response=response)

    def _execute_with_retry(self, method: str, url: str, request_func: Callable,
                            params: Optional[Dict[str, Any]] = None,
                            form_data: Any = None, body: Any = None,
                            headers: Optional[Dict[str, str]] = None) -> httpx.Response:
        """
        同步请求通用执行方法，封装重试逻辑

        :param method: 请求方法
        :param url: 请求URL
        :param request_func: 实际执行请求的函数
        :param params: 查询参数
        :param form_data: 表单数据
        :param body: JSON Body数据
        :param headers: 请求头
        :return: Response对象
        """
        attempt = 0
        while True:
            self._call_interceptors_before(method, url, params=params, data=form_data, json=body, headers=headers)
            try:
                response = request_func()
                self._call_interceptors_after(method, url, response=response)

                # 如果没有重试策略，或者请求成功，则直接返回
                if not self.retry_strategy:
                    self._raise_for_status(response=response, params=params, form_data=form_data, body=body)
                    return response

                # 如果需要重试
                should_retry, reason = self.retry_strategy.should_retry(attempt, method, url, response=response)
                if should_retry:
                    delay = self.retry_strategy.get_retry_delay(attempt)
                    if self.error_print_details:
                        self.logger.info(f"retry attempt {attempt + 1} for {method} {url} after {delay}s, reason: {reason}")
                    attempt += 1
                    import time
                    time.sleep(delay)
                    continue

                # 不需要重试，检查状态码并可能抛出异常
                self._raise_for_status(response=response, params=params, form_data=form_data, body=body)
                return response

            except Exception as e:
                if self.error_print_details:
                    self.logger.error(f"http {method.lower()} request error, params: {params}, url: {self._get_url(url=url)}, e: {e}, trace: {traceback.format_exc()}")
                self._call_interceptors_after(method, url, exception=e)

                # 如果有重试策略并且应该重试异常情况
                should_retry, reason = self.retry_strategy.should_retry(attempt, method, url, exception=e)
                if should_retry:
                    delay = self.retry_strategy.get_retry_delay(attempt)
                    if self.error_print_details:
                        self.logger.info(f"retry attempt {attempt + 1} for {method} {url} after {delay}s due to error: {e}, reason: {reason}")
                    attempt += 1
                    import time
                    time.sleep(delay)
                    continue

                # 不需要重试，直接抛出异常
                raise

    async def _execute_with_retry_async(self, method: str, url: str, request_func: Callable[[], Awaitable[httpx.Response]],
                                        params: Optional[Dict[str, Any]] = None,
                                        form_data: Any = None, body: Any = None,
                                        headers: Optional[Dict[str, str]] = None) -> httpx.Response:
        """
        异步请求通用执行方法，封装重试逻辑

        :param method: 请求方法
        :param url: 请求URL
        :param request_func: 实际执行请求的函数（协程）
        :param params: 查询参数
        :param form_data: 表单数据
        :param body: JSON Body数据
        :param headers: 请求头
        :return: Response对象
        """
        attempt = 0
        while True:
            self._call_interceptors_before(method, url, params=params, data=form_data, json=body, headers=headers)
            try:
                response = await request_func()
                self._call_interceptors_after(method, url, response=response)

                # 如果没有重试策略，或者请求成功，则直接返回
                if not self.retry_strategy:
                    self._raise_for_status(response=response, params=params, form_data=form_data, body=body)
                    return response

                # 如果需要重试
                should_retry, reason = self.retry_strategy.should_retry(attempt, method, url, response=response)
                if should_retry:
                    delay = self.retry_strategy.get_retry_delay(attempt)
                    if self.error_print_details:
                        self.logger.info(f"retry attempt {attempt + 1} for {method} {url} after {delay}s, reason: {reason}")
                    attempt += 1
                    await asyncio.sleep(delay)
                    continue

                # 不需要重试，检查状态码并可能抛出异常
                self._raise_for_status(response=response, params=params, form_data=form_data, body=body)
                return response

            except Exception as e:
                if self.error_print_details:
                    self.logger.error(f"http {method.lower()} request error, params: {params}, url: {self._get_url(url=url)}, e: {e}, trace: {traceback.format_exc()}")
                self._call_interceptors_after(method, url, exception=e)

                # 如果有重试策略并且应该重试异常情况
                should_retry, reason = self.retry_strategy.should_retry(attempt, method, url, exception=e)
                if should_retry:
                    delay = self.retry_strategy.get_retry_delay(attempt)
                    if self.error_print_details:
                        self.logger.info(f"retry attempt {attempt + 1} for {method} {url} after {delay}s due to error: {e}, reason: {reason}")
                    attempt += 1
                    await asyncio.sleep(delay)
                    continue

                # 不需要重试，直接抛出异常
                raise

    def get(self, url: str, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None) -> httpx.Response:
        """
        同步 GET 请求
        :param url: 请求地址
        :param params: 查询参数
        :param headers: 请求头
        :return: Response 对象
        """
        method = "GET"
        headers = {**self.headers, **headers} if headers else self.headers

        # 使用通用重试方法
        return self._execute_with_retry(
            method=method,
            url=url,
            request_func=lambda: self._client.get(url, params=params, headers=headers),
            params=params,
            headers=headers
        )

    def post(self, url: str, form_data: Any = None, body: Any = None, headers: Optional[Dict[str, str]] = None) -> httpx.Response:
        """
        同步 POST 请求
        :param url: 请求地址
        :param form_data: 表单数据
        :param body: JSON Body数据
        :param headers: 请求头
        :return: Response 对象
        """
        method = "POST"
        headers = {**self.headers, **headers} if headers else self.headers

        # 使用通用重试方法
        return self._execute_with_retry(
            method=method,
            url=url,
            request_func=lambda: self._client.post(url, data=form_data, json=body, headers=headers),
            form_data=form_data,
            body=body,
            headers=headers
        )

    async def aget(self, url: str, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None) -> httpx.Response:
        """
        异步 GET 请求
        :param url: 请求地址
        :param params: 查询参数
        :param headers: 请求头
        :return: Response 对象
        """
        method = "GET"
        headers = {**self.headers, **headers} if headers else self.headers

        # 使用通用异步重试方法
        return await self._execute_with_retry_async(
            method=method,
            url=url,
            request_func=lambda: self._async_client.get(url, params=params, headers=headers),
            params=params,
            headers=headers
        )

    async def apost(self, url: str, form_data: Any = None, body: Any = None, headers: Optional[Dict[str, str]] = None) -> httpx.Response:
        """
        异步 POST 请求
        :param url: 请求地址
        :param form_data: 表单数据
        :param body: JSON Body 数据
        :param headers: 请求头
        :return: Response 对象
        """
        method = "POST"
        headers = {**self.headers, **headers} if headers else self.headers

        # 使用通用异步重试方法
        return await self._execute_with_retry_async(
            method=method,
            url=url,
            request_func=lambda: self._async_client.post(url, data=form_data, json=body, headers=headers),
            form_data=form_data,
            body=body,
            headers=headers
        )
