#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-06-25 10:20.
# @author Horace
import atexit
import logging
import os

from weaviate.collections.classes.internal import GenerativeReturn
from weaviate.collections.classes.types import Properties

logger = logging.getLogger(__name__)

import weaviate

G_ENV_WEAVIATE_HOST = os.environ.get("WEAVIATE_HOST", "192.168.41.31")
g_weaviate_client = weaviate.connect_to_custom(
    http_host=G_ENV_WEAVIATE_HOST,
    http_port=8080,
    http_secure=False,
    grpc_host=G_ENV_WEAVIATE_HOST,
    grpc_port=50051,
    grpc_secure=False,
)

if g_weaviate_client.is_ready():
    logger.info("connected to weaviate successfully.")
else:
    logger.error("connecting to weaviate failed.")


def close_resources():
    if g_weaviate_client.is_ready():
        g_weaviate_client.close()
        logger.info("closed weaviate successfully.")


# 注册退出处理函数
atexit.register(close_resources)


def list_collection():
    """
    列出所有集合
    :return:
    """
    collections = g_weaviate_client.collections.list_all(simple=True)
    logger.info(f"list collections: {collections}")
    return collections


def create_collection(collection_name):
    """
    创建集合
    :return:
    """
    if not g_weaviate_client.collections.exists(collection_name):
        create_result = g_weaviate_client.collections.create(
            collection_name,
            vectorizer_config=weaviate.classes.config.Configure.Vectorizer.none(),
            multi_tenancy_config=weaviate.classes.config.Configure.multi_tenancy(enabled=True, auto_tenant_creation=True),
        )
        logger.debug(f"created collection successfully, result: {create_result}")
    else:
        logger.info(f"collection already exists, collection_name: {collection_name}")


def delete_collection(collection_name):
    """
    删除集合
    :return:
    """
    g_weaviate_client.collections.delete(collection_name)
    logger.info(f"deleted collection successfully, collection_name: {collection_name}")


def add_to_collection(collection_name, tenant, embedding, properties: Properties):
    """
    向集合中添加数据
    :return:
    """
    collection = g_weaviate_client.collections.get(collection_name).with_tenant(str(tenant))
    insert_result = collection.data.insert(
        properties=properties,
        vector=embedding,
    )
    logger.debug(f"inserted data successfully, result: {insert_result}")


def query_collection(collection_name, tenant, embedding, limit=3) -> GenerativeReturn:
    """
    查询集合中的数据
    :return:
    """
    questions = g_weaviate_client.collections.get(collection_name).with_tenant(str(tenant))
    query_result = questions.query.near_vector(
        near_vector=embedding,
        limit=limit,
        return_metadata=weaviate.classes.query.MetadataQuery(certainty=True)
    )
    return query_result


def delete_tenant_collection(collection_name, tenant):
    """
    删除集合中的数据
    """
    try:
        # 获取指定集合和租户的对象
        collection = g_weaviate_client.collections.get(collection_name).with_tenant(str(tenant))
        # 执行删除操作，删除该租户下的所有数据
        delete_result = collection.data.delete_many(
            where=weaviate.classes.query.Filter.by_property("text").like("*")
        )
        logger.info(f"deleted data for tenant {tenant} in collection {collection_name} successfully, result: {delete_result}")
    except Exception as e:
        logger.error(f"failed to delete data for tenant {tenant} in collection {collection_name}, error: {e}")
