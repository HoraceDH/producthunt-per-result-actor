#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-08-13 18:01.
# @author Horace
import logging

from basecommons.clients import serper_client
from commons.logger import init_logging

init_logging()
logger = logging.getLogger(__name__)

if __name__ == '__main__':
    search_items, knowledge_graph, related_search_list = serper_client.search("Apple inc")
    print(search_items)
    print(knowledge_graph)
    print(related_search_list)
