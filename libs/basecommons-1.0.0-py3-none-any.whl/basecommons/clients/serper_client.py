#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-08-13 16:29.
# @author Horace
import json
import logging
import os

from basecommons.clients.http_client import HttpClient

logger = logging.getLogger(__name__)
G_ENV_SERPER_API_KEY = os.environ.get("SERPER_API_KEY", "")
g_serper_http_client = HttpClient()


class SearchItem(object):
    """
    搜索结果的条目
    """

    def __init__(self, title: str = None, link: str = None, snippet: str = None, position: int = None):
        self.title = title
        self.link = link
        self.snippet = snippet
        self.position = position

    def __str__(self):
        return f"SearchItem(title={self.title}, link={self.link}, snippet={self.snippet}, position={self.position})"


def search(query: str, page: int = 1, page_size: int = 10, engine: str = "google") -> tuple[list[SearchItem], dict, list[str]]:
    """
    搜索内容
    :param query: 搜索关键词
    :param page: 页码
    :param page_size: 每页数量
    :param engine: 搜索引擎
    :return: 搜索结果，知识图谱（并不一定有），相关搜索词
    """
    if not G_ENV_SERPER_API_KEY:
        logger.error("SERPER_API_KEY is empty")
        return {}

    payload = json.dumps({
        "q": query,
        "num": page_size,
        "page": page,
        "engine": engine
    })
    headers = {
        'X-API-KEY': G_ENV_SERPER_API_KEY,
        'Content-Type': 'application/json'
    }
    response = g_serper_http_client.post(url="https://google.serper.dev/search", form_data=payload, headers=headers)
    data = response.json()

    knowledge_graph = data.get("knowledgeGraph", {})
    organic = data.get("organic", [])
    items = [
        SearchItem(
            title=item.get("title"),
            link=item.get("link"),
            snippet=item.get("snippet"),
            position=item.get("position"),
        )
        for item in organic
    ]

    # 相关搜索
    related_search_list = [
        related.get("query")
        for related in data.get("relatedSearches", [])
    ]
    return items, knowledge_graph, related_search_list
