#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-07-07 15:40.
# @author Horace
import enum
import logging
import os

import redis

from basecommons.clients.redis_key import get_lock_key

logger = logging.getLogger(__name__)

G_ENV_REDIS_HOST = os.environ.get("REDIS_HOST", "192.168.41.31")
G_ENV_REDIS_PORT = os.environ.get("REDIS_PORT", 6379)

####################### 初始化Redis客户端 #######################
def init_redis_client():
    """ 初始化Redis客户端 """
    global g_redis_client

    try:
        logger.info(f"start init redis client, redis_host: {G_ENV_REDIS_HOST}, redis_port: {G_ENV_REDIS_PORT}")
        g_redis_client = redis.Redis(host=G_ENV_REDIS_HOST, port=G_ENV_REDIS_PORT)
        g_redis_client.ping()
        logger.info(f"init redis client success, redis_host: {G_ENV_REDIS_HOST}, redis_port: {G_ENV_REDIS_PORT}")
        return g_redis_client
    except Exception as e:
        logger.error(f"init redis client failed, redis_host: {G_ENV_REDIS_HOST}, redis_port: {G_ENV_REDIS_PORT}, error: {e}")
        exit(1)


g_redis_client = init_redis_client()


def get_redis_client():
    """ 获取Redis客户端 """
    # TODO 这里可以做一些有效性的校验，如果客户端连接不健康，则重新初始化客户端
    return g_redis_client


####################### 初始化Redis客户端 #######################


####################### 定义Lua脚本 #######################
class ScriptEnum(enum.Enum):
    """ Lua脚本枚举 """

    # 删除已完成转录的音频字节
    enum_script_delete_completed_audio_bytes = enum.auto()


# 存储脚本常量与脚本SHA的映射，key：脚本常量，value：脚本sha
g_script_sha_map = {}

# 存储脚本常量与脚本内容的映射，key：脚本常量，value：脚本内容
g_script_content_map = {
    ScriptEnum.enum_script_delete_completed_audio_bytes: """
    local key = KEYS[1]
    local start_pos = tonumber(ARGV[1])
    local remaining_data = redis.call('getrange', key, start_pos, -1)
    redis.call('set', key, remaining_data)
    return string.len(remaining_data)
    """,

}


def __load_all_script():
    """ 初始化加载脚本 """
    for script_enum, script_content in g_script_content_map.items():
        __load_script(script_enum, script_content)


def __load_script(script_enum, script_content):
    """
    初始化加载脚本
    """
    script_sha = get_redis_client().script_load(script_content)
    g_script_sha_map[script_enum] = script_sha
    logger.info(f"load script success, script_key: {script_enum}, script_sha: {script_sha}, script_content: {script_content}")


# 初始化加载脚本
# __load_all_script()


####################### 定义Lua脚本 #######################

def lock(lock_name, lock_owner=None, lock_time_ms=2 * 1000):
    """
    加锁
    :param lock_name: 锁的名称
    :param lock_owner: 锁的拥有者
    :param lock_time_ms: 锁的时间，单位毫秒
    :return: 是否成功获取锁
    """
    if lock_owner is None:
        lock_owner = lock_name
    redis_client = get_redis_client()
    lock_key = get_lock_key(lock_name)
    lock_result = redis_client.set(lock_key, lock_owner, px=lock_time_ms, nx=True)
    logger.debug(f"get redis lock, key: {lock_key}, owner: {lock_owner}, lock_time_ms: {lock_time_ms}, result: {lock_result}")
    return lock_result


def unlock(lock_name, lock_owner=None):
    """
    解锁
    :param lock_name: 锁的名称
    :param lock_owner: 锁的拥有者
    :return: 是否成功释放锁
    """
    if lock_owner is None:
        lock_owner = lock_name
    redis_client = get_redis_client()
    lock_key = get_lock_key(lock_name)
    old_lock_owner = redis_client.get(lock_key)
    if old_lock_owner is None:
        return

    lock_owner = str(lock_owner)
    old_lock_owner = old_lock_owner.decode("UTF-8")

    # 简单做个比对，防止误删锁，更严谨做法可以使用lua脚本
    if old_lock_owner == lock_owner:
        redis_client.delete(lock_key)
        logger.debug(f"release redis lock, key: {lock_key}, owner: {lock_owner}, old_lock_owner: {old_lock_owner}")
    else:
        logger.info(f"release redis lock failed, the owner does not match, key: {lock_key}, owner: {lock_owner}, old_lock_owner: {old_lock_owner}")