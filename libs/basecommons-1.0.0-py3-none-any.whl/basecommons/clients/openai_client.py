#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-06-30 10:24.
# @author Horace
import atexit
import logging
import os

import httpx
from openai import OpenAI, Stream
from openai.types.chat import ChatCompletion, ChatCompletionChunk

from commons.logger import init_logging
G_ENV_OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")

logger = logging.getLogger(__name__)
# 代理地址
# proxy = "http://172.16.62.4:1087"
# http_client = httpx.Client(proxy=proxy)
proxies = {
    "http://": "socks5://us1-proxy.owll.ai:11800",
    "https://": "socks5://us1-proxy.owll.ai:11800",
}
http_client = httpx.Client(proxy=proxies["https://"])
g_openai_client = OpenAI(
    api_key=G_ENV_OPENAI_API_KEY,
    http_client=http_client
)


def close_resources():
    g_openai_client.close()
    logger.info("closed openai client successfully.")


# 注册退出处理函数
atexit.register(close_resources)


def generate_embedding(text, model="text-embedding-ada-002") -> list[float]:
    """
    获取文本向量
    :param text: 文本
    :param model: OpenAI 模型
    :return:
    """
    response = g_openai_client.embeddings.create(
        input=text,
        model=model
    )
    return response.data[0].embedding


def generate_text(user_prompt, system_prompt=None, delete_blank: bool = True, model="gpt-4.1") -> str:
    """
    使用OpenAI生成文本
    :param user_prompt: 用户提示词
    :param system_prompt: 系统提示词，如果没有，则不组装
    :param delete_blank: 是否删除空白字符，包括空格、换行等，默认删除
    :param model: OpenAI模型
    :return: 生成的文本
    """
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": user_prompt})
    response = g_openai_client.chat.completions.create(
        model=model,
        messages=messages,
    )
    result = response.choices[0].message.content
    result = result.replace("```json", "")
    result = result.replace("```", "")
    if delete_blank:
        result = result.replace(" ", "")
        result = result.replace("\r\n", "")
        result = result.replace("""
    """, "")
    return result


def generate_streaming_response(user_prompt, system_prompt=None, model="gpt-4.1") -> ChatCompletion | Stream[
    ChatCompletionChunk]:
    """
    使用OpenAI生成流式文本
    :param user_prompt: 用户提示词
    :param system_prompt: 系统提示词，如果没有，则不组装
    :param model: OpenAI模型
    :return: 流式的Response
    """
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": user_prompt})
    response = g_openai_client.chat.completions.create(
        model=model,
        messages=messages,
        stream=True
    )
    return response


if __name__ == '__main__':
    init_logging()
    user_prompt = """ AI产业目前发生了什么重大事件？ """
    json_array = ""
    response = generate_streaming_response(user_prompt)
    for chunk in response:
        logger.debug(f"response chunk: {chunk}")
        content = chunk.choices[0].delta.content
        if content is None or content == "":
            continue
        json_array += content
    logger.info(json_array)
