#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-08-12 10:52.
# @author Horace

import logging
import operator

logger = logging.getLogger(__name__)


# [
#     {
#         "name": "download_growth_alert",
#         "conditions": {
#             "all": [
#                 {"fact": "download_growth", "operator": "greaterThan", "value": 0.2}
#             ]
#         }
#     },
#     {
#         "name": "revenue_growth_alert",
#         "conditions": {
#             "any": [
#                 {"fact": "revenue_growth", "operator": "greaterThan", "value": 0.3},
#                 {"fact": "download_growth", "operator": "greaterThan", "value": 0.5}
#             ]
#         }
#     }
# ]
class RuleEngineService:
    """
    轻量级规则引擎，支持简单的规则定义和执行。
    """

    def __init__(self):
        self.rules = []
        self.operators = {
            "equal": operator.eq,
            "notEqual": operator.ne,
            "greaterThan": operator.gt,
            "greaterThanInclusive": operator.ge,
            "lessThan": operator.lt,
            "lessThanInclusive": operator.le,
            "in": lambda a, b: a in b,
            "notIn": lambda a, b: a not in b
        }

    def add_rule(self, rule: dict):
        """
        添加单条规则，规则格式参考示例。
        :param rule: 规则定义，参考示例。
        :return:
        """
        self.rules.append(rule)

    def add_rules(self, rules: list):
        """
        批量添加规则，规则格式参考示例。
        :param rules: 规则列表，参考示例。
        :return: None
        """
        self.rules.extend(rules)

    def _evaluate_condition(self, condition: dict, facts: dict) -> bool:
        """
        递归计算条件，支持 AND、OR 嵌套。
        :param condition: 条件定义，参考示例。
        :param facts: 事实数据，参考示例。
        :return: 条件是否满足。
        """
        if "all" in condition:  # AND
            return all(self._evaluate_condition(c, facts) for c in condition["all"])
        if "any" in condition:  # OR
            return any(self._evaluate_condition(c, facts) for c in condition["any"])

        # 单条件判断
        fact_value = facts.get(condition["fact"])
        if fact_value is None:
            raise ValueError(f"Fact not found: {condition['fact']}")
        op_func = self.operators.get(condition["operator"])
        if op_func is None:
            raise ValueError(f"Unsupported operator: {condition['operator']}")
        return op_func(fact_value, condition["value"])

    def run(self, facts: dict) -> list[str]:
        """
        执行规则，返回触发的事件列表。
        :param facts: 事实数据，参考示例。
        :return: 触发的规则名称列表，没有命中则返回None
        """
        triggered_rules = []
        for rule in self.rules:
            if self._evaluate_condition(rule["conditions"], facts):
                triggered_rules.append(rule["name"])
        return triggered_rules if len(triggered_rules) > 0 else None

    def clear_rules(self):
        """
        清除所有规则。
        :return: None
        """
        self.rules = []
