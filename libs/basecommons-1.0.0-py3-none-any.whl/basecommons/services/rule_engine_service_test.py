#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-08-12 10:57.
# @author Horace
import logging

from service.rule_engine_service import RuleEngineService

logger = logging.getLogger(__name__)

if __name__ == '__main__':
    # 定义规则
    rules = [
        {
            "name": "download_growth_alert",
            "conditions": {
                "any": [
                    {"fact": "download_growth", "operator": "greaterThan", "value": 0.1},
                    {"fact": "download_growth", "operator": "lessThan", "value": 0.3},
                ]
            }
        },
        {
            "name": "revenue_growth_alert",
            "conditions": {
                "any": [
                    {"fact": "revenue_growth", "operator": "greaterThan", "value": 0.3},
                    {"fact": "download_growth", "operator": "greaterThan", "value": 0.5}
                ]
            }
        }
    ]

    # 创建引擎并添加规则
    engine = RuleEngineService()
    engine.add_rules(rules)

    # 模拟 t_app 表当天计算结果
    facts = {"download_growth": 0.4, "revenue_growth": 0.2}

    # 执行
    names = engine.run(facts)

    # 输出触发结果
    for name in names:
        print(f"trigger rule: {name}")
