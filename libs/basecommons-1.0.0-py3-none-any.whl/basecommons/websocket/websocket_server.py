#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-06-20 10:01.
# @author Horace
import logging

import tornado

from basecommons.websocket.websocket_context import g_websocket_mainloop
from basecommons.websocket.websocket_handler import WebSocketHandler

logger = logging.getLogger(__name__)


def create_websocket():
    """创建WebSocket服务"""

    # Tornado的I/O模型是基于事件循环的
    return tornado.web.Application([
        ("/websocket", WebSocketHandler),
    ],
        # 生产环境推荐配置
        max_buffer_size=104857600,  # 100MB，控制单个连接的最大缓冲区大小
        websocket_ping_interval=5,  # 30秒发送一次ping
        websocket_ping_timeout=60,  # 60秒无响应则关闭连接
        max_body_size=10485760,  # 限制请求体大小为10MB
        max_header_size=65536,  # 限制请求头大小为64KB
        idle_connection_timeout=300,  # 空闲连接超时时间为300秒
        debug=True,  # 调试模式，生产环境关闭
        xheaders=True  # 支持代理传递真实IP
    )


def start_server(bind="0.0.0.0", port=1578):
    """
    启动WebSocket服务
    :param bind: 绑定的IP地址
    :param port: 绑定的端口号
    """
    websocket = create_websocket()
    logger.info(f"start websocket server on port {port}")
    websocket.listen(port=port, address=bind)
    g_websocket_mainloop.start()
