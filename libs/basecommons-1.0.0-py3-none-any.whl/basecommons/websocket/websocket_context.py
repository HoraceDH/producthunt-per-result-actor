#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-06-20 10:55.
# @author Horace
import logging

import tornado
from tornado.websocket import WebSocketClosedError

logger = logging.getLogger(__name__)
# 异步主循环对象
g_websocket_mainloop = tornado.ioloop.IOLoop.current()

# 客户端连接池，用于存储每个客户端的连接对象
# key: unique_id, value: WebSocketHandler
g_websocket_connections = {}


def __send_message_to_client(unique_id, message):
    """
    发送消息到客户端
    :param unique_id: 唯一ID
    :param message: 消息内容
    """
    try:
        websocket_controller = g_websocket_connections[unique_id]
        if websocket_controller is None:
            logger.warning(f"websocket connection not found, unique_id: {unique_id}")
            return
        websocket_controller.write_message(message)
        logger.debug(f"send message to client, unique_id: {unique_id}, message: {message}")
    except WebSocketClosedError as e:
        # 如果连接已经关闭，则删除该连接
        logger.warning(f"websocket connection closed, unique_id: {unique_id}")
        del g_websocket_connections[unique_id]


def send_message_in_mainloop(unique_id, message):
    """
    在IOLoop中发送消息到客户端
    :param unique_id: 唯一ID
    :param message: 消息内容
    """
    try:
        g_websocket_mainloop.add_callback(__send_message_to_client, unique_id, message)
    except Exception as e:
        logger.error(f"add callback to mainloop error, unique_id: {unique_id}, message: {message}, error: {e}")
