#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-06-20 10:08.
# @author Horace
import logging
from concurrent.futures.thread import ThreadPoolExecutor

import tornado.websocket

from basecommons.websocket.websocket_context import g_websocket_connections

logger = logging.getLogger(__name__)
websocket_executor = ThreadPoolExecutor(max_workers=300)


class WebSocketHandler(tornado.websocket.WebSocketHandler):
    """
    处理WebSocket连接的请求，每个连接一个实例对象
    """

    def __init__(self, application, request, **kwargs):
        super().__init__(application, request, **kwargs)

    def check_origin(self, origin):
        """允许跨域请求"""
        return True

    # 客户端连接时触发
    async def open(self):
        unique_id = self.get_query_argument("uniqueId", None)
        remote_ip = self.request.remote_ip
        # 保存连接信息
        g_websocket_connections[unique_id] = self
        logger.info(f"client connected, unique_id: {unique_id}, remote_ip: {remote_ip}, id: {id(self)}")

    # 接收消息时触发
    async def on_message(self, message):
        unique_id = self.get_query_argument("uniqueId", None)
        remote_ip = self.request.remote_ip
        logger.debug(f"received message, unique_id: {unique_id}, remote_ip: {remote_ip}, object_id: {id(self)}, length: {len(message)}")

        try:
            # 如果收到的是字节
            if isinstance(message, bytes):
                websocket_executor.submit(self.print_websocket_message, unique_id, message)

        except Exception as e:
            logger.error(f"error occurred while receiving message, unique_id: {unique_id}, remote_ip: {remote_ip}, e: {e}", exc_info=True)

    # 连接关闭时触发
    async def on_close(self):
        identify = self.get_query_argument('identify', None)
        remote_ip = self.request.remote_ip
        logger.info(f"client disconnected, identify: {identify}, remote_ip: {remote_ip}")

    def print_websocket_message(self, unique_id, message):
        logger.info(f"received message, unique_id: {unique_id}, length: {len(message)}")
