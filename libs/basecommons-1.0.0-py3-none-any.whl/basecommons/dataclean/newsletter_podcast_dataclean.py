#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-10-29 10:42.
# @author Horace

import logging

from lxml import html
from lxml.html import HtmlElement

logger = logging.getLogger(__name__)


class NewsLetterPodcastDataClean:
    """ 数据清洗服务 """

    def __init__(self):
        pass

    def clean_news_letter_html_content(self, id: int, html_content: str) -> dict:
        """
        清洗newsletter的HTML内容，返回结构化的数据
        :param id: 记录id
        :param html_content: newsletter的HTML内容
        :return: 结构化的数据
        """
        result = {}
        if not html_content:
            return result
        tree = html.fromstring(html_content)

        result["youtube_url"] = self.__get_youtube_url(id, tree)

        # 取人员介绍（包含子标签内容）
        result["interviewee_intro"] = self.__get_interviewee_intro(id, tree)

        # 讨论主题
        result["discuss"] = self.__get_discuss(id, tree)

        # 讨论主题, we_cover
        result["we_covers"] = self.__get_we_covers(id, tree)

        # 联系地址
        result["contact_address"] = self.__get_contact_address(id, tree)

        # 引用内容
        result["references"] = self.__get_reference(id, tree)

        # 推荐书籍
        result["recommend_books"] = self.__get_recommend_books(id, tree)

        # 最大的收获
        result["biggest_takeaways"] = self.__get_biggest_takeaways(id, tree)
        return result

    def __get_youtube_url(self, id: int, tree: HtmlElement) -> str:
        """
        获取youtube链接
        :param id: 记录id
        :param tree: 文档元素
        :return:
        """
        a_elements = tree.xpath('//a[starts-with(@href, "https://youtu.be")]')
        if not a_elements or len(a_elements) == 0:
            logger.warning(f"failed to get youtube url, id: {id}")
            return ""
        return a_elements[0].get("href")


    def __get_interviewee_intro(self, id: int, tree: HtmlElement) -> str:
        """
        获取 interviewee 介绍
        :param id: 记录id
        :param tree: 文档元素
        :return:
        """
        element = self.__find_we_discuss_element(tree)
        if element is None:
            logger.warning(f"failed to get interviewee intro, id: {id}")
            return ""

        interviewee_intro = None
        element = element.getprevious()
        for i in range(3) :
            interviewee_intro = element.text_content().strip()
            if interviewee_intro is not None and interviewee_intro.strip() != "":
                return interviewee_intro
            element = element.getprevious()

        # 获取上一个节点的文本内容
        if interviewee_intro is None or interviewee_intro.strip() == "":
            logger.warning(f"failed to get interviewee intro, id: {id}")
            return ""
        return interviewee_intro

    def __get_discuss(self, id: int, tree: HtmlElement) -> list[dict]:
        """
        获取讨论主题
        :param id: 记录id
        :param tree: 文档元素
        :return:
        """
        we_discuss = []
        element = self.__find_we_discuss_element(tree)
        if element is None:
            logger.warning(f"failed to get discuss, id: {id}")
            return []

        for item in element.getnext().xpath(".//li"):
            a_element = item.xpath('.//a/@href')
            discuss = {
                "title": item.text_content().strip(),
                "youtube_url": a_element and a_element[0] or "",
            }
            # 包含html标签
            # discuss = html.tostring(item, method='html', encoding='unicode').strip()
            we_discuss.append(discuss)

        if len(we_discuss) == 0:
            temp_element = element.getnext()
            for i in range(15):
                # 可能是p
                if temp_element is not None and temp_element.tag == "p":
                    content = temp_element.text_content()
                    if content is None or content.strip() == "" or content.endswith(":"):
                        break
                    a_element = temp_element.xpath('.//a/@href')
                    we_discuss.append({
                        "title": content,
                        "youtube_url": a_element and a_element[0] or "",
                    })
                temp_element = temp_element.getnext()

        if we_discuss is None or len(we_discuss) == 0:
            logger.warning(f"failed to get discuss, id: {id}")
            return []
        return we_discuss

    def __get_contact_address(self, id: int, tree: HtmlElement) -> list[dict]:
        """
        获取联系地址
        :param id: 记录id
        :param tree: 文档元素
        :return:
        """
        contact_address_list = []
        element = self.__find_contact_address_element(tree)
        if element is None:
            logger.warning(f"failed to get contact address, id: {id}")
            return contact_address_list

        p_element = element.getnext()
        while True:
            urls = p_element.xpath(".//a/@href")
            if p_element.tag == "h3" or not p_element.text or urls is None or len(urls) == 0 or urls[0].strip() == "":
                break
            title = self.__get_text_without_tag(element=p_element, tags=["a"])
            title = title and title.replace("• ", "").replace("•", "").replace(":", "").strip()
            contact_address = {
                "title": title,
                "url": urls[0]
            }
            contact_address_list.append(contact_address)
            p_element = p_element.getnext()

        if contact_address_list is None or len(contact_address_list) == 0:
            logger.warning(f"failed to get contact address, id: {id}")
            return contact_address_list
        return contact_address_list

    def __get_reference(self, id: int, tree: HtmlElement) -> list[dict]:
        """
        获取引用内容
        :param id: 记录id
        :param tree: 文档元素
        :return:
        """
        reference_list = []
        element = self.__find_reference_element(tree)
        if element is None:
            logger.warning(f"failed to get reference, id: {id}")
            return reference_list
        p_element = element.getnext()
        while True:
            urls = p_element.xpath(".//a/@href")
            if p_element.tag == "h3" or not p_element.text or urls is None or len(urls) == 0 or urls[0].strip() == "":
                break
            title = self.__get_text_without_tag(element=p_element, tags=["a"])
            title = title and title.replace("• ", "").replace("•", "").replace(":", "").strip()
            reference = {
                "title": title,
                "url": urls[0],
            }
            reference_list.append(reference)
            p_element = p_element.getnext()

        if reference_list is None or len(reference_list) == 0:
            logger.warning(f"failed to get reference, id: {id}")
            return reference_list
        return reference_list

    def __get_text_without_tag(self, element: HtmlElement, tags: list[str]) -> str:
        """
        获取元素的文本内容(包括子元素的文本内容)，去掉指定的标签内容
        :param element: 元素
        :param tags: 标签列表
        :return: 文本内容
        """
        result = element.text or ""
        children = element.getchildren()
        for child in children:
            if child.tag in tags:
                continue
            # 是否还有子节点
            if child.getchildren():
                result += self.__get_text_without_tag(child, tags)
            else:
                result += child.text
        return result

    def __get_recommend_books(self, id: int, tree: HtmlElement) -> list[dict]:
        """
        获取推荐书籍
        :param id: 记录id
        :param tree: 文档元素
        :return:
        """
        recommend_books = []
        element = self.__find_recommend_book_element(tree)
        if element is None:
            logger.warning(f"failed to get recommended books, id: {id}")
            return recommend_books
        p_element = element.getnext()
        while True:
            if p_element.tag == "div" or not p_element.text_content():
                break
            title = self.__get_text_without_tag(element=p_element, tags=["a"])
            title = title and title.replace("• ", "").replace("•", "").replace(":", "").strip()
            recommend_book = {
                "title": title,
                "url": p_element.xpath(".//a/@href")[0]
            }
            recommend_books.append(recommend_book)
            p_element = p_element.getnext()

        if recommend_books is None or len(recommend_books) == 0:
            logger.warning(f"failed to get recommended books, id: {id}")
            return recommend_books
        return recommend_books

    def __get_biggest_takeaways(self, id: int, tree: HtmlElement) -> list[dict]:
        """
        获取最大的收获
        :param id: 记录id
        :param tree: 文档元素
        :return:
        """
        biggest_takeaways = []
        element = self._find_takeaways_element(tree)
        if element is None:
            logger.warning(f"failed to get biggest takeaways, id: {id}")
            return biggest_takeaways

        temp_element = element.getnext()
        for i in range(3):
            if temp_element is None:
                break
            if temp_element.tag == "ol" or temp_element.tag == "ul":
                children = temp_element.getchildren()
                for child in children:
                    biggest_takeaways.append(child.text_content())
            temp_element = temp_element.getnext()

        if len(biggest_takeaways) == 0:
            temp_element = element.getnext()
            for i in range(15):
                # 可能是p
                if temp_element is not None and temp_element.tag == "p":
                    content = temp_element.text_content()
                    if content is None or content.endswith(":"):
                        break
                    biggest_takeaways.append(content)
                temp_element = temp_element.getnext()

        if len(biggest_takeaways) == 0:
            logger.warning(f"failed to get biggest takeaways, id: {id}")
        return biggest_takeaways

    def __find_element(self, tree: HtmlElement, keywords: list[str], tags: list[str]) -> HtmlElement:
        """
        不区分大小写的方式，根据内容查找元素
        :param tree: 文档元素
        :param keywords: 关键词列表
        :param tags: 标签列表
        :return: 元素
        """
        for keyword in keywords:
            for tag in tags:
                # .表示当前节点的所有文本内容
                xpath = f"//{tag}[contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), \"{keyword.lower()}\")]"
                elements = tree.xpath(xpath)
                if not elements or len(elements) == 0:
                    continue
                return elements[0]
        return None

    def _find_takeaways_element(self, tree: HtmlElement) -> HtmlElement:
        """
        查找takeaways元素
        :param tree: 文档元素
        :return: takeaways元素
        """
        keywords = ["My biggest takeaways from this conversation", "Some takeaways", "biggest takeaways:"]
        tags = ["h2", "h3", "h4", "h5", "h6", "p"]
        return self.__find_element(tree, keywords, tags)

    def __find_we_discuss_element(self, tree: HtmlElement) -> HtmlElement:
        """
        查找 we discuss 元素
        :param tree: 文档元素
        :return:
        """
        keywords = ["we discuss:", "what you’ll learn:", "you'll learn", "will learn:", "Learn:", "we cover:", "shares:"]
        tags = ["p"]
        return self.__find_element(tree, keywords, tags)

    def __find_contact_address_element(self, tree: HtmlElement) -> HtmlElement:
        """
        查找联系地址元素
        :param tree: 文档元素
        :return: 联系地址元素
        """
        keywords = ["Where to find"]
        tags = ["h3", "p"]
        return self.__find_element(tree, keywords, tags)

    def __find_reference_element(self, tree: HtmlElement) -> HtmlElement:
        """
        查找引用元素
        :param tree: 文档元素
        :return: 引用元素
        """
        keywords = ["Referenced:"]
        tags = ["h3", "p"]
        return self.__find_element(tree, keywords, tags)

    def __find_recommend_book_element(self, tree: HtmlElement) -> HtmlElement:
        """
        查找推荐书籍元素
        :param tree: 文档元素
        :return: 推荐书籍元素
        """
        keywords = ["Recommended books:", "Recommended book:"]
        tags = ["h3", "p"]
        return self.__find_element(tree, keywords, tags)

    def __get_we_covers(self, id: int, tree: HtmlElement) -> HtmlElement:
        we_covers = []
        element = self.__find_we_cover_element(tree)
        if element is None:
            logger.warning(f"failed to get we covers, id: {id}")
            return []

        for item in element.getnext().xpath(".//li"):
            a_element = item.xpath('.//a/@href')
            we_cover = {
                "title": item.text_content().strip(),
                "youtube_url": a_element and a_element[0] or "",
            }
            we_covers.append(we_cover)

        if len(we_covers) == 0:
            temp_element = element.getnext()
            for i in range(15):
                # 可能是p
                if temp_element is not None and temp_element.tag == "p":
                    content = temp_element.text_content()
                    if content is None or content.strip() == "" or content.endswith(":"):
                        break
                    a_element = temp_element.xpath('.//a/@href')
                    we_covers.append({
                        "title": content,
                        "youtube_url": a_element and a_element[0] or "",
                    })
                temp_element = temp_element.getnext()

        if we_covers is None or len(we_covers) == 0:
            logger.warning(f"failed to get we covers, id: {id}")
            return []
        return we_covers

    def __find_we_cover_element(self, tree: HtmlElement) -> HtmlElement:
        """
        查找 we cover 元素
        :param tree: 文档元素
        :return: we cover 元素
        """
        keywords = ["we cover:"]
        tags = ["h3", "p"]
        return self.__find_element(tree, keywords, tags)