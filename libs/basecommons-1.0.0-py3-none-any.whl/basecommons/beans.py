#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-08-04 22:33.
# @author Horace
import logging
from dataclasses import dataclass
from typing import List, Any

logger = logging.getLogger(__name__)


@dataclass
class HotRankItem:
    """
    热榜条目
    """
    hot_word: str = ""  # 热词
    hot_value: Any = 0  # 热度值，可能是绝对值，可能是格式化后的值
    label: str = ""  # 热度标签
    label_url: str = ""  # 热度标签链接
    url: str = ""  # 链接
    desc: str = ""  # 摘要描述


@dataclass
class HotRankList:
    """
    热榜列表
    """
    update_time: str
    hot_rank_list: List[HotRankItem]
