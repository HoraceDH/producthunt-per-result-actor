#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-07-07 15:30.
# @author Horace
import logging

logger = logging.getLogger(__name__)
from enum import Enum, unique
from typing import NamedTuple


class MsgCodesTuple(NamedTuple):
    """状态码和消息的命名元组"""
    code: int
    msg: str


@unique
class MsgCodes(Enum):
    """API响应状态码枚举"""
    SUCCESS = MsgCodesTuple(0, "")
    ERROR_PARAMS = MsgCodesTuple(400, "参数错误")
    ERROR = MsgCodesTuple(1000, "未知错误")

    @property
    def code(self):
        """获取状态码"""
        return self.value.code

    @property
    def msg(self):
        """获取消息"""
        return self.value.msg


class MsgObject(object):
    """API响应对象"""

    def __init__(self, msg_code=MsgCodes.SUCCESS, msg=None, data=None):
        """
        初始化API响应对象
        :param msg_code: 状态码
        :param data: 数据
        """

        self.msg_object = {
            "code": msg_code.code,
            "msg": msg or msg_code.msg,
            "data": self.convert_to_dict(data)
        }

    def convert_to_dict(self, obj) -> dict:
        """
        将对象转为字典格式
        :param obj: 待转换的对象
        :return: 转换后的字典
        """
        if obj is None:
            return None
        if hasattr(obj, 'model_to_dict'):
            return obj.model_to_dict()
        elif hasattr(obj, "__dict__"):
            return obj.__dict__
        elif isinstance(obj, (list, tuple)):
            return [self.convert_to_dict(item) for item in obj]
        else:
            return obj

    def to_dict(self):
        """转换为字典格式"""
        return self.msg_object

    @classmethod
    def success(cls, data=None):
        """
        返回成功响应
        :return:
        """
        return MsgObject(data=data).to_dict()

    @classmethod
    def error(cls, msg: str, msg_code: MsgCodes = MsgCodes.ERROR):
        """
        错误响应
        :param msg_code: 错误码
        :param msg: 自定义错误消息
        :return:
        """
        return MsgObject(msg_code=msg_code, msg=msg).to_dict()
