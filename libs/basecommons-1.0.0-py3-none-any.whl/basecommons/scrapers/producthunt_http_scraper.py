#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-11-11 21:31.
# @author Horace

import logging

from basecommons.clients.http_client import HttpClient
from basecommons.scrapers.producthunt_scraper import ProductHuntScraper

logger = logging.getLogger(__name__)


class ProductHuntHttpScraper(ProductHuntScraper):
    """
    Http版本的Producthunt Scraper，用于从Producthunt获取产品数据
    """

    def __init__(self, leaderboard_daily_page_sha256_hash: str, products_page_layout_sha256_hash: str, post_page_comments_sha256_hash: str,
                 product_about_page_sha256_hash: str, product_page_launching_today_sha256_hash: str, leaderboard_weekly_page_sha256_hash: str,
                 leaderboard_monthly_page_sha256_hash: str, leaderboard_yearly_page_sha256_hash: str, sleep_seconds_per_page: int = 0.2,
                 sleep_seconds_per_detail: int = 0.2, logger=None, error_print_details: bool = False, headers: dict = None):
        """
        Product Hunt 爬虫
        :param leaderboard_daily_page_sha256_hash: 应用列表的 sha256Hash
        :param products_page_layout_sha256_hash: 应用详情的 sha256Hash
        :param post_page_comments_sha256_hash: 应用评论的 sha256Hash
        :param product_about_page_sha256_hash: 应用关于页面的 sha256Hash
        :param product_page_launching_today_sha256_hash: 应用发布相关信息的 sha256Hash
        :param sleep_seconds_per_page: 每一页睡眠的时间
        :param logger: 日志记录器
        :param error_print_details: 是否打印错误详情
        :param headers: 请求头
        """
        super().__init__(leaderboard_daily_page_sha256_hash, products_page_layout_sha256_hash, post_page_comments_sha256_hash, product_about_page_sha256_hash, product_page_launching_today_sha256_hash,
                         leaderboard_weekly_page_sha256_hash, leaderboard_monthly_page_sha256_hash, leaderboard_yearly_page_sha256_hash, sleep_seconds_per_page, sleep_seconds_per_detail, logger,
                         error_print_details, headers)
        self.http_client = HttpClient(headers=self.headers, logger=self.logger, error_print_details=self.error_print_details)

    async def init(self):
        pass

    async def get_apps_by_url(self, url: str) -> dict:
        """
        根据URL获取应用列表
        :param url: 应用列表URL
        :return: 应用列表JSON对象
        """
        response = self.http_client.get(url)
        return response.json()

    async def get_app_detail_by_url(self, url: str) -> dict:
        """
        根据URL地址获取应用详情
        :param url: 应用详情URL
        :return: 应用详情JSON对象
        """
        response = self.http_client.get(url)
        return response.json()

    async def get_about_page_info_by_url(self, url: str) -> dict:
        """
        获取应用关于页面的信息
        :param url: 应用关于页面的URL
        :return: 应用关于页面的信息
        """
        response = self.http_client.get(url)
        return response.json()

    async def get_launching_info_by_url(self, url: str) -> dict:
        """
        获取应用发布相关信息
        :param url: 应用发布相关信息URL
        :return: 应用发布相关信息JSON对象
        """
        response = self.http_client.get(url)
        return response.json()

    async def get_app_comments_by_url(self, url: str) -> dict:
        """
        从Producthunt获取应用评论
        :param url: 应用评论URL
        :return: 应用评论JSON对象
        """
        response = self.http_client.get(url)
        return response.json()

    async def close(self):
        """
        关闭Scraper，释放资源
        :return:
        """
        self.http_client.close()
