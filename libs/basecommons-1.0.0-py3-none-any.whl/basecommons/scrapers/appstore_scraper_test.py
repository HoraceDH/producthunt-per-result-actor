#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-10-21 15:42.
# @author Horace
import logging

from basecommons.logger import init_logging
from basecommons.scrapers.appstore_scraper import AppStoreScraper
from basecommons.utils.json_utils import to_json_string

logger = logging.getLogger(__name__)
if __name__ == '__main__':
    init_logging()
    appstore_scraper = AppStoreScraper()
    # reviews = appstore_scraper.get_reviews(app_id="6443947003", country="us", limit=500)
    # print(f"received {len(reviews)} comments")
    # print(to_json_string(reviews))

    app_details = appstore_scraper.get_app_details(id="6443947003")
    print(to_json_string(app_details))

    # 测试获取该开发者ID下的应用
    # app_details = appstore_scraper.get_app_details(id="284417353", limit=1)
    # print(f"received {len(app_details)} apps")
    # print(to_json_string(app_details))

    # app_details_list = appstore_scraper.search_app_details(keyword="抖音", country="us", limit=5)
    # print(f"received {len(app_details_list)} apps")
    # print(to_json_string(app_details_list))

    # free_app_rank_list = appstore_scraper.get_app_rank(country="us", feed="top-paid", limit=10)
    # print(to_json_string(free_app_rank_list))
