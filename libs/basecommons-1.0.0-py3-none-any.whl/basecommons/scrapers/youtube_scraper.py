#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-11-06 09:48.
# @author Horace

import logging
import os
import re
import tempfile
import uuid
from pathlib import Path

import yt_dlp

from basecommons.clients.http_client import HttpClient
from basecommons.utils import time_utils, dict_utils
from basecommons.utils.json_utils import to_json_object, to_json_string

logger = logging.getLogger(__name__)


class YoutubeScraper:
    """ YouTube Crawler """

    def __init__(self, custom_loger=None, download_path=None):
        """
        初始化YouTube爬取器
        :param custom_loger: 日志记录器
        :param download_path: 下载路径
        """
        self.logger = custom_loger or logger
        # 获取系统临时目录路径，如果不存在则创建
        self.download_path = download_path or tempfile.gettempdir() + "/youtube_downloads"
        if not os.path.exists(self.download_path):
            os.makedirs(self.download_path)

        self.headers = {
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "accept-language": "zh-CN,zh;q=0.9,ja;q=0.8,en;q=0.7",
            "cache-control": "no-cache",
            "pragma": "no-cache",
            "priority": "u=0, i",
            "sec-ch-dpr": "1",
            "sec-ch-ua": "\"Chromium\";v=\"142\", \"Google Chrome\";v=\"142\", \"Not_A Brand\";v=\"99\"",
            "sec-ch-ua-arch": "\"arm\"",
            "sec-ch-ua-bitness": "\"64\"",
            "sec-ch-ua-form-factors": "\"Desktop\"",
            "sec-ch-ua-full-version": "\"142.0.7444.60\"",
            "sec-ch-ua-full-version-list": "\"Chromium\";v=\"142.0.7444.60\", \"Google Chrome\";v=\"142.0.7444.60\", \"Not_A Brand\";v=\"99.0.0.0\"",
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-model": "\"\"",
            "sec-ch-ua-platform": "\"macOS\"",
            "sec-ch-ua-platform-version": "\"15.6.1\"",
            "sec-ch-ua-wow64": "?0",
            "sec-ch-viewport-width": "1001",
            "sec-fetch-dest": "document",
            "sec-fetch-mode": "navigate",
            "sec-fetch-site": "same-origin",
            "sec-fetch-user": "?1",
            "upgrade-insecure-requests": "1",
            # "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36",
            "x-browser-channel": "stable",
            "x-browser-copyright": "Copyright 2025 Google LLC. All rights reserved.",
            "x-browser-validation": "d//u4R5DiWup/ApEN0L4er68I4A=",
            "x-browser-year": "2025",
        }
        self.http_client = HttpClient(headers=self.headers)

    def clean_expired_files(self, expired_days: int = 3):
        """
        清理过期文件，文件的创建时间超过指定的天数，则删除该文件
        :param expired_days: 过期天数
        """
        now = int(time_utils.get_current_timestamp() / 1000)
        for file in os.listdir(self.download_path):
            file_path = os.path.join(self.download_path, file)
            if os.path.isfile(file_path):
                file_mtime = int(os.path.getmtime(file_path))
                if now - file_mtime > expired_days * 24 * 60 * 60:
                    os.remove(file_path)
                    self.logger.info(f"clean expired file, path: {file_path}")

    def get_video_ids(self, url: str, limit: int = 100) -> list[str]:
        """
        从YouTube上获取视频ID
        :param url: YouTube 频道链接，例如：https://www.youtube.com/@20VC/videos
        :param limit: 获取视频数量限制
        :return: YouTube 视频ID列表
        """
        video_ids = []
        response = self.http_client.get(url=url)

        # 使用正则表达式提取出匹配的文本
        matches = re.findall("var ytInitialData = .*};</script>", response.text)
        if not matches:
            self.logger.error(f"failed to get youtube video ids, url: {url}, text: {response.text}")
            return []

        init_data = matches[0].replace("var ytInitialData = ", "").replace(";</script>", "")
        video_json_object = to_json_object(init_data)
        video_tabs = dict_utils.safe_get(video_json_object, "contents", "twoColumnBrowseResultsRenderer", "tabs")
        if len(video_tabs) < 1:
            self.logger.error(f"failed to get youtube video ids, video tabs not found, url: {url}, init_data: {init_data}")
            return []

        video_objects = dict_utils.safe_get(video_tabs[1], "tabRenderer", "content", "richGridRenderer", "contents")
        if not video_objects:
            self.logger.error(f"failed to get youtube video ids, video objects not found, url: {url}, init_data: {init_data}")
            return []

        for video in video_objects:
            video_id = dict_utils.safe_get(video, "richItemRenderer", "content", "videoRenderer", "videoId")
            if not video_id:
                self.logger.warning(f"failed to get youtube video id, url: {url}, video_object: {to_json_string(video)}")
                continue
            video_ids.append(video_id)

        self.logger.info(f"get youtube video ids, url: {url}, length: {len(video_ids)}")
        return video_ids[:limit]

    def get_video_info(self, youtube_url: str = None, video_id: str = None) -> dict:
        """
        从YouTube上获取视频信息
        :param youtube_url: YouTube 视频URL，有提供则直接使用，否则从视频ID构建
        :param video_id: YouTube 视频ID
        :return: YouTube 视频信息字典
        """
        url = youtube_url or f"https://www.youtube.com/watch?v={video_id}"
        try:
            ydl_opts = {
                "quiet": True,
                "no_warnings": True,
                "referer": "https://www.youtube.com/",
                "nocheckcertificate": True,
                "user_agent": self.headers["user-agent"],
                "http_headers": {
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                    "Accept-Language": "en-us,en;q=0.5",
                    "Sec-Fetch-Mode": "navigate",
                },
            }
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                video_info = ydl.extract_info(url, download=False)
                return video_info
        except Exception as e:
            self.logger.error(f"failed to get youtube video info, video_id: {video_id}, url: {url}, error: {e}")
        return {}

    def __convert_simple_video_info(self, video_info: dict, captions: bool = False, caption_language: str = "en") -> dict:
        """
        转换简单的视频信息
        :param video_info: YouTube 视频信息字典
        :return: 简单的视频信息字典
        """
        result = {
            "id": video_info.get("id"),
            "url": video_info.get("webpage_url"),
            "duration": video_info.get("duration"),
            "duration_string": video_info.get("duration_string"),
            "view_count": video_info.get("view_count"),
            "categories": video_info.get("categories", []),
            "title": video_info.get("fulltitle"),
            "thumbnail": video_info.get("thumbnail"),
            "chapters": self.__convert_chapters(video_info.get("id", ""), video_info.get("chapters", [])),
            "description": self.__get_real_description(video_info.get("description")),
            "comment_count": video_info.get("comment_count"),
            "release_time": time_utils.parse_timestamp_to_date(video_info.get("timestamp")),
            "captions": self.__convert_captions(video_info.get("automatic_captions"), caption_language) if captions else None,
        }
        return result

    def get_simple_video_info(self, youtube_url: str = None, video_id: str = None, captions: bool = False, caption_language: str = "en") -> dict:
        """
        获取简单的视频信息
        :param youtube_url: YouTube 视频URL，有提供则直接使用，否则从视频ID构建
        :param video_id: YouTube 视频ID
        :param captions: 是否获取字幕
        :param caption_language: 字幕语言，默认英语
        :return: YouTube 视频信息字典
        """
        video_info = self.get_video_info(youtube_url=youtube_url, video_id=video_id)
        return self.__convert_simple_video_info(video_info, captions, caption_language)

    def __get_real_description(self, description: str) -> str:
        """
        获取视频描述中的实际描述
        :param description: YouTube 视频描述
        :return: 实际描述字符串
        """
        if not description:
            return ""
        return description.split("\n-------")[0]

    def __convert_chapters(self, video_id: str, chapters: list[dict]) -> list[dict]:
        """
        转换章节
        :param video_id 视频ID
        :param chapters: YouTube 视频章节列表
        :return: 转换后的章节列表
        """
        result = []
        for chapter in chapters:
            start_time = int(chapter.get("start_time", 0))
            url = f"https://youtu.be/{video_id}?t={start_time}"
            chapter.update({"url": url})
            result.append(chapter)
        return result

    def __convert_captions(self, captions: dict, language: str = "en") -> str:
        """
        转换字幕
        :param captions: 字幕参数
        :param language: 字幕语言，默认英语
        :return: 转换后的字幕字符串
        """
        en_captions_list = dict_utils.safe_get(captions, language)
        if not en_captions_list:
            self.logger.warning(f"failed to get youtube captions, captions not found, captions: {captions}")
            return None

        en_caption_url = dict_utils.safe_get(en_captions_list[0], "url")
        if not en_caption_url:
            self.logger.warning(f"failed to get youtube captions, captions url not found, captions: {en_captions_list}")
            return None
        response = self.http_client.get(en_caption_url)
        en_captions = response.json()
        events = dict_utils.safe_get(en_captions, "events", default=[])

        total_text = ""
        for event in events:
            segs = event.get("segs", [])
            if not segs:
                continue
            total_text += ''.join([seg.get('utf8', '') for seg in segs]) + " "
        return total_text.replace("\n", "").replace("  ", " ").strip()

    def download_audio(self, youtube_url: str = None, video_id: str = None, audio_format: str = "mp3", audio_quality: str = "192",
                       output_filename: str = None, default_captions: bool = False, caption_language: str = "en") -> tuple[str, dict]:
        """
        下载视频音频
        :param youtube_url: YouTube 视频URL，有提供则直接使用，否则从视频ID构建
        :param video_id: YouTube 视频ID
        :param audio_format: 音频格式，默认mp3
        :param audio_quality: 音频质量，默认192kbps
        :param output_filename: 输出文件名，默认视频标题
        :param default_captions: 是否默认获取字幕，该字幕由yt-dlp获取，默认False
        :param caption_language: 字幕语言，针对的是默认字幕，默认英语
        :return: 音频文件路径, 视频信息
        """
        url = youtube_url or f"https://www.youtube.com/watch?v={video_id}"
        output_filename = output_filename or video_id or uuid.uuid4().hex
        try:
            logger.info(f"start download youtube audio, video_id: {video_id}, url: {url}")
            ydl_opts = {
                "format": "bestaudio/best",
                "postprocessors": [{
                    "key": "FFmpegExtractAudio",
                    "preferredcodec": audio_format,
                    "preferredquality": audio_quality,
                }],
                "outtmpl": os.path.join(self.download_path, f"{output_filename}.%(ext)s"),
                "quiet": False,
                "no_warnings": False,
                "nocheckcertificate": True,
                "user_agent": self.headers["user-agent"],
                "referer": "https://www.youtube.com/",
                "http_headers": {
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-us,en;q=0.5',
                    'Sec-Fetch-Mode': 'navigate',
                },
                "extractor_args": {
                    "youtube": {
                        "player_client": ["android", "web"],
                        "skip": ["hls", "dash"],
                    }
                },
            }

            audio_file = None
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                video_info = ydl.extract_info(url, download=True)
                filename = ydl.prepare_filename(video_info)
                audio_file = str(Path(filename).with_suffix(f".{audio_format}"))
                logger.info(f"download youtube audio success, video_id: {video_id}, audio_file: {audio_file}")
            return audio_file, self.__convert_simple_video_info(video_info=video_info, captions=default_captions, caption_language=caption_language)
        except Exception as e:
            self.logger.error(f"failed to download youtube audio, video_id: {video_id}, error: {e}")
        return None, None

    def download_video(self, youtube_url: str = None, video_id: str = None, output_filename: str = None,
                       default_captions: bool = False, caption_language: str = "en") -> tuple[str, dict]:
        """
        下载视频
        :param youtube_url: YouTube 视频URL，有提供则直接使用，否则从视频ID构建
        :param video_id: YouTube 视频ID
        :param output_filename: 输出文件名，默认视频标题
        :param default_captions: 是否默认获取字幕，该字幕由yt-dlp获取，默认False
        :param caption_language: 字幕语言，针对的是默认字幕，默认英语
        :return: 视频文件路径, 视频信息
        """
        url = youtube_url or f"https://www.youtube.com/watch?v={video_id}"
        output_filename = output_filename or video_id or uuid.uuid4().hex
        try:
            logger.info(f"start download youtube video, video_id: {video_id}, url: {url}")

            # 配置下载选项 - 添加更多选项以避免 403 错误
            ydl_opts = {
                "format": "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best",
                "outtmpl": os.path.join(self.download_path, f"{output_filename}.%(ext)s"),
                "quiet": False,
                "no_warnings": False,
                # 添加以下选项来避免 403 错误
                "nocheckcertificate": True,
                "user_agent": self.headers["user-agent"],
                "referer": "https://www.youtube.com/",
                "http_headers": {
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                    "Accept-Language": "en-us,en;q=0.5",
                    "Sec-Fetch-Mode": "navigate",
                },
                "extractor_args": {
                    "youtube": {
                        "player_client": ["android", "web"],
                        "skip": ["hls", "dash"],
                    }
                },
            }

            # 下载视频
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                filename = ydl.prepare_filename(info)
                logger.info(f"download youtube video success, video_id: {video_id}, filename: {filename}")
                return filename, self.__convert_simple_video_info(video_info=info, captions=default_captions, caption_language=caption_language)
        except Exception as e:
            self.logger.error(f"failed to download youtube video, video_id: {video_id}, url: {url}, error: {e}")
            return None, None


if __name__ == '__main__':
    init_logging()
    crawler_youtube = YoutubeScraper()
    # video_ids = crawler_youtube.get_video_ids('https://www.youtube.com/@20VC/videos')
    # logger.info(to_json_string(video_ids))
    #
    # audio_file, video_info = crawler_youtube.download_audio(video_id="51y4KatMBFI")
    # logger.info(f"audio_file: {audio_file}, video_info: {to_json_string(video_info)}")

    video_info = crawler_youtube.get_simple_video_info(video_id="51y4KatMBFI")
    logger.info(f"video_info: {to_json_string(video_info)}")
