#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-08-05 14:52.
# @author Horace
import hashlib
import json
import logging
import re
import traceback
from urllib.parse import urlencode

from basecommons.clients.http_client import HttpClient
from basecommons.beans import HotRankList, HotRankItem
from basecommons.utils.encode_utils import encode_params
from basecommons.utils.time_utils import get_current_time_format

g_logger = logging.getLogger(__name__)


class HotRankScraper(object):
    """
    热榜爬虫
    """

    def __init__(self, logger=None, timeout_seconds: int = 10, error_print_url: bool = True):
        """
        初始化
        :param logger: 日志对象
        :param timeout_seconds: 请求超时时间
        :param error_print_url: 异常时是否打印url
        """
        self.logger = logger if logger is not None else g_logger
        headers = {
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "accept-encoding": "identity",
            "accept-language": "zh-CN,zh;q=0.9,ja;q=0.8,en;q=0.7",
            "priority": "u=0, i",
            "sec-ch-ua": '"Not)A;Brand";v="8", "Chromium";v="138", "Google Chrome";v="138"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"macOS"',
            "sec-fetch-dest": "document",
            "sec-fetch-mode": "navigate",
            "sec-fetch-site": "none",
            "sec-fetch-user": "?1",
            "upgrade-insecure-requests": "1",
            "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
        }
        self.http_client = HttpClient(timeout_seconds=timeout_seconds, headers=headers)
        self.timeout_seconds = timeout_seconds
        self.error_print_url = error_print_url

    async def get_douyin_hot_rank_list(self) -> tuple[bool, HotRankList]:
        """
        爬取抖音热榜信息
        :return: (success, hot_rank_list)
        """
        url = "https://www.iesdouyin.com/web/api/v2/hotsearch/billboard/word/"
        try:
            # 发送GET请求并设置头信息
            headers = {"Referer": "https://www.douyin.com/"}
            response = self.http_client.get(url, headers=headers)

            # 解析JSON响应，假设热榜数据在'word_list'字段中
            data = response.json()
            status_code = data.get("status_code", -1000)
            if status_code != 0:
                self.logger.error(f"get douyin hot rank failed, status_code: {status_code}, data: {data}")
                return False, []

            hot_list = data.get("word_list", [])
            hot_rank_list = [
                HotRankItem(
                    hot_word=hot_item.get("word", ""),
                    hot_value=hot_item.get("hot_value", 0),
                    url=f"https://www.douyin.com/search/{encode_params(hot_item.get("word", ""))}",
                    label=hot_item.get("label", ""),
                )
                for hot_item in hot_list
            ]
            self.logger.debug(f"get douyin hot rank success, data: {data}")
            return True, HotRankList(update_time=data.get("active_time", ""), hot_rank_list=hot_rank_list)
        except Exception as e:
            self.logger.error(f"get douyin hot rank error: {e}, traceback: {traceback.format_exc()}")
        return False, []

    async def get_zhihu_hot_rank_list(self) -> tuple[bool, HotRankList]:
        """
        爬取知乎热榜信息
        :return: (success, hot_rank_list)
        """
        url = "https://www.zhihu.com/api/v3/feed/topstory/hot-list-web?limit=50&desktop=true"
        try:
            # 发送GET请求并设置头信息
            headers = {"Referer": "https://www.zhihu.com/"}
            response = self.http_client.get(url, headers=headers)

            data = response.json()
            hot_list = data.get("data", [])
            hot_rank_list = [
                HotRankItem(
                    hot_word=hot_item.get("target", {}).get("title_area", {}).get("text", ""),
                    hot_value=hot_item.get("target", {}).get("metrics_area", {}).get("text", "").replace("热度", ""),
                    label="",
                    url=hot_item.get("target", {}).get("link", {}).get("url", ""),
                    desc=hot_item.get("target", {}).get("excerpt_area", {}).get("text", ""),
                )
                for hot_item in hot_list
            ]
            self.logger.debug(f"get zhihu hot rank success, data: {data}")
            return True, HotRankList(update_time=get_current_time_format(), hot_rank_list=hot_rank_list)
        except Exception as e:
            self.logger.error(f"get zhihu hot rank error: {e}, traceback: {traceback.format_exc()}")
        return False, []

    async def get_wallstcn_hot_rank_list(self) -> tuple[bool, HotRankList]:
        """
        爬取华尔街见闻热门文章列表
        :return: (success, hot_rank_list)
        """
        url = "https://api-one.wallstcn.com/apiv1/content/articles/hot?period=all"
        try:
            # 发送GET请求并设置头信息
            headers = {"Referer": "https://wallstreetcn.com/"}
            response = self.http_client.get(url, headers=headers)

            data = response.json().get("data", {})
            hot_list = data.get("day_items", [])
            hot_rank_list = [
                HotRankItem(
                    hot_word=hot_item.get("title", ""),
                    hot_value=hot_item.get("pageviews", 0),
                    label="",
                    url=hot_item.get("uri", ""),
                    desc="",
                )
                for hot_item in hot_list
            ]
            self.logger.debug(f"get wallstcn hot rank success, data: {data}")
            return True, HotRankList(update_time=get_current_time_format(), hot_rank_list=hot_rank_list)
        except Exception as e:
            self.logger.error(f"get wallstcn hot rank error: {e}, traceback: {traceback.format_exc()}")
        return False, []

    async def get_hupu_hot_rank_list(self) -> tuple[bool, HotRankList]:
        """
        爬取虎扑步行街主干道热帖列表
        :return: (success, hot_rank_list)
        """
        url = "https://api.vvhan.com/api/hotlist/huPu"
        try:
            # 发送GET请求并设置头信息
            headers = {"Referer": "https://www.hupu.com/"}
            response = self.http_client.get(url, headers=headers)

            data = response.json()
            update_time = data.get("update_time", "")
            # update_time = get_current_time_format()

            hot_list = data.get("data", [])
            hot_rank_list = [
                HotRankItem(
                    hot_word=hot_item.get("title", ""),
                    hot_value=hot_item.get("hot", ""),
                    label="",
                    url=hot_item.get("url", ""),
                    desc="",
                )
                for hot_item in hot_list
            ]
            self.logger.debug(f"get hupu hot rank success, data: {data}")
            return True, HotRankList(update_time=update_time, hot_rank_list=hot_rank_list)
        except Exception as e:
            self.logger.error(f"get hupu hot rank error: {e}, traceback: {traceback.format_exc()}")
        return False, []

    async def get_baidu_tieba_hot_rank_list(self) -> tuple[bool, HotRankList]:
        """
        爬取百度贴吧热议列表
        :return: (success, hot_rank_list)
        """
        url = "https://tieba.baidu.com/hottopic/browse/topicList"
        try:
            # 发送GET请求并设置头信息
            headers = {"Referer": "https://tieba.baidu.com/"}
            response = self.http_client.get(url, headers=headers)

            data = response.json()
            # update_time = data.get("update_time", "")
            update_time = get_current_time_format()

            hot_list = data.get("data", {}).get("bang_topic", {}).get("topic_list", [])
            hot_rank_list = [
                HotRankItem(
                    hot_word=hot_item.get("topic_name", ""),
                    hot_value=hot_item.get("discuss_num", ""),
                    label="",
                    url=hot_item.get("topic_url", ""),
                    desc=hot_item.get("topic_desc", ""),
                )
                for hot_item in hot_list
            ]
            self.logger.debug(f"get baidu tieba hot rank success, data: {data}")
            return True, HotRankList(update_time=update_time, hot_rank_list=hot_rank_list)
        except Exception as e:
            self.logger.error(f"get baidu tieba hot rank error: {e}, traceback: {traceback.format_exc()}")
        return False, []

    async def get_toutiao_hot_rank_list(self) -> tuple[bool, HotRankList]:
        """
        爬取今日头条热门文章列表
        :return: (success, hot_rank_list)
        """
        url = "https://www.toutiao.com/hot-event/hot-board/?origin=toutiao_pc"
        try:
            # 发送GET请求并设置头信息
            headers = {"Referer": "https://www.toutiao.com/"}
            response = self.http_client.get(url, headers=headers)

            data = response.json()
            # update_time = data.get("update_time", "")
            update_time = get_current_time_format()

            hot_list = data.get("data", [])
            hot_rank_list = [
                HotRankItem(
                    hot_word=hot_item.get("Title", ""),
                    hot_value=hot_item.get("HotValue", ""),
                    label="",
                    url=f"https://www.toutiao.com/trending/{hot_item.get("ClusterIdStr", "")}",
                    desc="",
                )
                for hot_item in hot_list
            ]
            self.logger.debug(f"get toutiao hot rank success, data: {data}")
            return True, HotRankList(update_time=update_time, hot_rank_list=hot_rank_list)
        except Exception as e:
            self.logger.error(f"get toutiao hot rank error: {e}, traceback: {traceback.format_exc()}")
        return False, []

    async def get_thepaper_hot_rank_list(self) -> tuple[bool, HotRankList]:
        """
        爬取澎湃热榜列表
        :return: (success, hot_rank_list)
        """
        url = "https://cache.thepaper.cn/contentapi/wwwIndex/rightSidebar"
        try:
            # 发送GET请求并设置头信息
            headers = {"Referer": "https://www.thepaper.cn/"}
            response = self.http_client.get(url, headers=headers)

            data = response.json().get("data", {})
            # update_time = data.get("update_time", "")
            update_time = get_current_time_format()

            hot_list = data.get("hotNews", [])
            hot_rank_list = [
                HotRankItem(
                    hot_word=hot_item.get("name", ""),
                    hot_value=hot_item.get("praiseTimes", 0),
                    label="",
                    url=f"https://www.thepaper.cn/newsDetail_forward_{hot_item.get("contId", "")}",
                    desc="",
                )
                for hot_item in hot_list
            ]
            self.logger.debug(f"get thepaper hot rank success, data: {data}")
            return True, HotRankList(update_time=update_time, hot_rank_list=hot_rank_list)
        except Exception as e:
            self.logger.error(f"get thepaper hot rank error: {e}, traceback: {traceback.format_exc()}")
        return False, []

    def __get_cls_search_params(self, more_params=None):
        """
        针对财联社接口请求签名
        """
        search_params = {
            "app": "CailianpressWeb",
            "os": "web",
            "sv": "8.4.6"
        }

        if more_params:
            search_params.update(more_params)

        # 对参数进行排序
        sorted_params = dict(sorted(search_params.items()))

        # 生成签名
        param_str = urlencode(sorted_params)
        sha1_hash = hashlib.sha1(param_str.encode()).hexdigest()
        md5_sign = hashlib.md5(sha1_hash.encode()).hexdigest()

        sorted_params["sign"] = md5_sign
        return sorted_params

    async def get_cls_hot_rank_list(self) -> tuple[bool, HotRankList]:
        """
        爬取财联社热门文章列表
        :return: (success, hot_rank_list)
        """
        url = "https://www.cls.cn/v2/article/hot/list"
        try:
            # 发送GET请求并设置头信息
            headers = {"Referer": "https://www.cls.cn/"}
            response = self.http_client.get(f"{url}?{urlencode(self.__get_cls_search_params())}", headers=headers)

            data = response.json()
            # update_time = data.get("update_time", "")
            update_time = get_current_time_format()

            hot_list = data.get("data", [])
            hot_rank_list = [
                HotRankItem(
                    hot_word=hot_item.get("title", ""),
                    hot_value=hot_item.get("readNum", 0),
                    label="",
                    url=f"https://www.cls.cn/detail/{hot_item.get("id", "")}",
                    desc=hot_item.get("brief", ""),
                )
                for hot_item in hot_list
            ]
            self.logger.debug(f"get cls hot rank success, data: {data}")
            return True, HotRankList(update_time=update_time, hot_rank_list=hot_rank_list)
        except Exception as e:
            self.logger.error(f"get cls hot rank error: {e}, traceback: {traceback.format_exc()}")
        return False, []

    async def get_bilibili_search_hot_rank_list(self) -> tuple[bool, HotRankList]:
        """
        爬取哔哩哔哩热搜列表
        :return: (success, hot_rank_list)
        """
        url = "https://s.search.bilibili.com/main/hotword?limit=50"
        try:
            # 发送GET请求并设置头信息
            headers = {"Referer": "https://www.bilibili.com/"}
            response = self.http_client.get(url, headers=headers)

            data = response.json()
            # update_time = data.get("update_time", "")
            update_time = get_current_time_format()

            hot_list = data.get("list", [])
            hot_rank_list = [
                HotRankItem(
                    hot_word=hot_item.get("keyword", ""),
                    hot_value=hot_item.get("heat_score", 0),
                    label="",
                    label_url=hot_item.get("icon", ""),
                    url=f"https://search.bilibili.com/all?keyword={url_encode(hot_item.get("keyword", ""))}",
                    desc="",
                )
                for hot_item in hot_list
            ]
            self.logger.debug(f"get bilibili search hot rank success, data: {data}")
            return True, HotRankList(update_time=update_time, hot_rank_list=hot_rank_list)
        except Exception as e:
            self.logger.error(f"get bilibili search hot rank error: {e}, traceback: {traceback.format_exc()}")
        return False, []

    async def get_baidu_search_hot_rank_list(self) -> tuple[bool, HotRankList]:
        """
        爬取百度热搜列表
        :return: (success, hot_rank_list)
        """
        url = "https://top.baidu.com/board?tab=realtime"
        try:
            # 发送GET请求并设置头信息
            headers = {"Referer": "https://www.baidu.com/"}
            response = self.http_client.get(url, headers=headers)

            # 通过正则表达式获取数据：<!--s-data:(.*?)-->
            raw = response.text
            data = re.findall(r"<!--s-data:(.*?)-->", raw)
            if data is None or len(data) <= 0:
                return False, []
            data = json.loads(data[0])

            # update_time = data.get("update_time", "")
            update_time = get_current_time_format()

            hot_list = data.get("data", {}).get("cards", [{}])[0].get("content", [])
            hot_rank_list = [
                HotRankItem(
                    hot_word=hot_item.get("query", ""),
                    hot_value=hot_item.get("hotScore", 0),
                    label="",
                    label_url=hot_item.get("icon", ""),
                    url=hot_item.get("rawUrl", ""),
                    desc="",
                )
                for hot_item in hot_list
            ]
            self.logger.debug(f"get baidu hot search hot rank success, data: {data}")
            return True, HotRankList(update_time=update_time, hot_rank_list=hot_rank_list)
        except Exception as e:
            self.logger.error(f"get baidu hot search hot rank error: {e}, traceback: {traceback.format_exc()}")
        return False, []
