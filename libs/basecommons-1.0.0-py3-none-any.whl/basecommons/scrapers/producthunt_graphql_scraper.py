#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-11-13 12:13.
# @author Horace
import logging

import requests

from basecommons.utils.json_utils import to_json_string

logger = logging.getLogger(__name__)
DEVELOPER_TOKEN = "A92tdSJMf1Goq-T6HCBCk5IJNSKk4J4BN26-6M23OaQ"  # 替换为你的 token
API_URL = "https://api.producthunt.com/v2/api/graphql"
HEADERS = {
    "Authorization": f"Bearer {DEVELOPER_TOKEN}",
    "Accept": "application/json",
    "Content-Type": "application/json"
}


def run_query(query: str, variables: dict = None) -> dict:
    """执行 GraphQL 查询，返回 JSON 结果或抛出异常。"""
    payload = {"query": query}
    if variables is not None:
        payload["variables"] = variables
    response = requests.post(API_URL, headers=HEADERS, json=payload)
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Query failed with status {response.status_code}: {response.text}")


# ——— 查询示例 ———
# 获取最近（first=5）条产品信息：id、name、tagline、votesCount
query = """
query GetLatestProducts($first: Int!) {
  posts(first: $first) {
    edges {
      node {
        id
        name
        tagline
        votesCount
        featuredAt
      }
    }
  }
}
"""

variables = {"first": 5}

if __name__ == "__main__":
    result = run_query(query, variables)
    # 打印整理后的结果
    posts = result.get("data", {}).get("posts", {}).get("edges", [])
    for edge in posts:
        node = edge.get("node", {})
        print(to_json_string(node))
