#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-11-02 11:36.
# @author Horace
import asyncio
import logging
from datetime import datetime

from basecommons.logger import init_logging
from basecommons.scrapers.producthunt_nodriver_scraper import ProductHuntNodriverScraper
from basecommons.utils.json_utils import to_json_string

init_logging()

logger = logging.getLogger(__name__)


async def main():
    headers = {
        "Accept": "*/*",
        "Accept-Language": "zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2",
        "Alt-Used": "www.producthunt.com",
        "Connection": "keep-alive",
        "Priority": "u=0",
        "Referer": "https://www.producthunt.com/leaderboard/daily/2025/11/8/all",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
        "TE": "trailers",
        "User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:144.0) Gecko/20100101 Firefox/144.0",
        "rsc": "1"
    }

    producthunt_scraper = ProductHuntNodriverScraper(
        headers=headers,
        leaderboard_daily_page_sha256_hash="547bb5ae92ec9a7a5ba5a4007def856e7c9ab781a03f9f80060c8656816a6b5a",
        leaderboard_weekly_page_sha256_hash="74a5405972fc0b6a8e704d6970968116d8fb6021db27d95bad59f376bbba12d4",
        leaderboard_monthly_page_sha256_hash="f065039c66bd56fcf12df875964041cfae45a46a7e3a2673881c4c3a8aab331b",
        leaderboard_yearly_page_sha256_hash="95f012b71a92552aca2a9747e29737be9a859759e9a0caee240833154974341f",
        products_page_layout_sha256_hash="2e4adeec4ad8aa6e86e8aa70f6de8fc8875df91a09a3178585307911aaaf1e66",
        post_page_comments_sha256_hash="3c55cdfbdb7e2de4089fe7143bb75f1f4118ba83547755d893c0e44be60209e4",
        product_about_page_sha256_hash="60bfee0fe656e44436990869a1f3bab22f48e6c2707cfe250f5774099898235e",
        product_page_launching_today_sha256_hash="b19f54bc200934031bb21ec37ae1ca5bf2b6cace3a4c8f9f7eefd54de5d42db7",
        error_print_details=True,
    )
    await producthunt_scraper.init()
    apps = await producthunt_scraper.get_apps(cycle="day", week=4, date=datetime(2025, 11, 5), limit=1)
    print(to_json_string(apps))
    await producthunt_scraper.close()

    # comments = asyncio.run(producthunt_scraper.get_app_comments(slug="ai-context-flow", limit=10))
    # print(to_json_string(comments))

    # detail = asyncio.run(producthunt_scraper.get_app_detail(slug="swetrix-analytics"))
    # print(to_json_string(detail))


if __name__ == '__main__':
    asyncio.run(main())
