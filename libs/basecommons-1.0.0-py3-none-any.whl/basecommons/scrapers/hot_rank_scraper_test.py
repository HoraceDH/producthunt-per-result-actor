#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-08-05 15:39.
# @author Horace
import asyncio
import logging

from basecommons.logger import init_logging
from hot_rank_scraper import HotRankScraper
from basecommons.utils.json_utils import to_json_string

logger = logging.getLogger(__name__)

if __name__ == '__main__':
    init_logging()

    hot_rank_scraper = HotRankScraper()
    # success, hot_rank_list = asyncio.run(hot_rank_scraper.get_douyin_hot_rank_list())
    # success, hot_rank_list = asyncio.run(hot_rank_scraper.get_zhihu_hot_rank_list())
    # success, hot_rank_list = asyncio.run(hot_rank_scraper.get_wallstcn_hot_rank_list())
    # success, hot_rank_list = asyncio.run(hot_rank_scraper.get_hupu_hot_rank_list())
    # success, hot_rank_list = asyncio.run(hot_rank_scraper.get_baidu_tieba_hot_rank_list())
    # success, hot_rank_list = asyncio.run(hot_rank_scraper.get_toutiao_hot_rank_list())
    # success, hot_rank_list = asyncio.run(hot_rank_scraper.get_thepaper_hot_rank_list())
    # success, hot_rank_list = asyncio.run(hot_rank_scraper.get_cls_hot_rank_list())
    # success, hot_rank_list = asyncio.run(hot_rank_scraper.get_bilibili_search_hot_rank_list())
    success, hot_rank_list = asyncio.run(hot_rank_scraper.get_baidu_search_hot_rank_list())

    logger.info(f"get hot rank list, success: {success}, hot_rank_list: {to_json_string(hot_rank_list)}")
