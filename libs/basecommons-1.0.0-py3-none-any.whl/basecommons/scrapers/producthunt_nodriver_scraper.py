#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-11-11 21:36.
# @author Horace
import logging
from datetime import datetime, timedelta

from nodriver import start

from basecommons.scrapers.producthunt_scraper import ProductHuntScraper
from basecommons.utils.json_utils import to_json_object

logger = logging.getLogger(__name__)


class ProductHuntNodriverScraper(ProductHuntScraper):
    """
    nodriver版本的Producthunt Scraper，用于从Producthunt获取产品数据，注意每一次的数据获取，都需要新建一个对象
    """

    def __init__(self, leaderboard_daily_page_sha256_hash: str, products_page_layout_sha256_hash: str, post_page_comments_sha256_hash: str,
                 product_about_page_sha256_hash: str, product_page_launching_today_sha256_hash: str, leaderboard_weekly_page_sha256_hash: str,
                 leaderboard_monthly_page_sha256_hash: str, leaderboard_yearly_page_sha256_hash: str, sleep_seconds_per_page: int = 0.2,
                 sleep_seconds_per_detail: int = 0.2, logger=None, error_print_details: bool = False, headers: dict = None):
        """
        Product Hunt 爬虫
        :param leaderboard_daily_page_sha256_hash: 应用列表的 sha256Hash
        :param products_page_layout_sha256_hash: 应用详情的 sha256Hash
        :param post_page_comments_sha256_hash: 应用评论的 sha256Hash
        :param product_about_page_sha256_hash: 应用关于页面的 sha256Hash
        :param product_page_launching_today_sha256_hash: 应用发布相关信息的 sha256Hash
        :param sleep_seconds_per_page: 每一页睡眠的时间
        :param logger: 日志记录器
        :param error_print_details: 是否打印错误详情
        :param headers: 请求头
        """
        super().__init__(leaderboard_daily_page_sha256_hash, products_page_layout_sha256_hash, post_page_comments_sha256_hash, product_about_page_sha256_hash, product_page_launching_today_sha256_hash,
                         leaderboard_weekly_page_sha256_hash, leaderboard_monthly_page_sha256_hash, leaderboard_yearly_page_sha256_hash, sleep_seconds_per_page, sleep_seconds_per_detail, logger,
                         error_print_details, headers)

        self.__browser = None
        self.__tab = None

    async def init(self):
        """
        初始化 nodriver 浏览器
        :return:
        """
        self.__browser = await start(headless=False, browser_args=[
            "--disable-gpu",
            "--disable-setuid-sandbox",
            "--disable-dev-shm-usage",
            "--disable-extensions",
            "--disable-features=VizDisplayCompositor",
            "--no-zygote",
            "--disable-software-rasterizer",
            "--window-size=1920,1080",
            "--auto-open-devtools-for-tabs",  # 自动为每个标签页打开开发者工具
            "--remote-debugging-port=9222",  # 启用远程调试端口
        ])
        tmp_date = datetime.now() - timedelta(days=1)
        self.__tab = await self.__browser.get(f"https://www.producthunt.com/leaderboard/daily/{tmp_date.year}/{tmp_date.month}/{tmp_date.day}/all")

        # 等待页面加载完成
        await self.__tab.wait_for("div[id='root-container']")

    async def __send_request_with_nodriver(self, url: str) -> dict:
        """
        在浏览器中发起请求
        :param url: 请求的URL
        """
        result = await self.__tab.evaluate(expression=f"""
            fetch('{url}', {{
                "method": "GET",
                "credentials": "include"
            }})
            .then(response => response.json())
            .then(data => ({{success: 'success', data: JSON.stringify(data)}}))
            .catch(error => ({{error: 'error', error: error.message}}));
        """, await_promise=True, return_by_value=True)

        values = result.to_json().get("deepSerializedValue").get("value")
        if len(values) < 2 or values[0][0] != "success":
            logger.warning(f"get product hunt apps failed, result: {values}")
            return {}

        json_string = values[1][1].get("value")
        return to_json_object(json_string)

    async def get_apps_by_url(self, url: str) -> dict:
        return await self.__send_request_with_nodriver(url)

    async def get_app_detail_by_url(self, url: str) -> dict:
        return await self.__send_request_with_nodriver(url)

    async def get_about_page_info_by_url(self, url: str) -> dict:
        return await self.__send_request_with_nodriver(url)

    async def get_launching_info_by_url(self, url: str) -> dict:
        return await self.__send_request_with_nodriver(url)

    async def get_app_comments_by_url(self, url: str) -> dict:
        return await self.__send_request_with_nodriver(url)

    async def close(self):
        """
        关闭Scraper，释放资源
        :return:
        """
        await self.__tab.close()
