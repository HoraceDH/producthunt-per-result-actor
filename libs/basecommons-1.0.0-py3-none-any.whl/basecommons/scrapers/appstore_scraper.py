#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-10-21 00:05.
# @author Horace
import logging

from basecommons.clients.http_client import HttpClient, DefaultRetryStrategy
from basecommons.utils.json_utils import to_json_string

g_logger = logging.getLogger(__name__)


class AppStoreScraper:
    """
    AppStore的爬虫

    RSS Feed Generator：https://rss.marketingtools.apple.com/
    """

    def __init__(self, logger=None):
        self.logger = logger if logger is not None else g_logger
        self.http_client = HttpClient()

    def get_reviews(self, app_id: str, country: str = "us", limit: int = 100) -> list[dict]:
        """
        获取AppStore上的评论
        :param app_id: AppStore上的应用ID
        :param country: 国家，例如"us"表示美国，"cn"表示中国
        :param limit: 获取的评论数量，默认100条
        :return: 评论列表，每个评论是一个字典，包含评论的相关信息
        """
        page = 1
        reviews = []
        country = country.lower()

        # AppStore限制最多只能获取500条评论
        if limit > 500:
            limit = 500

        while True:
            url = f"https://itunes.apple.com/{country}/rss/customerreviews/page={page}/id={app_id}/sortby=mostrecent/json"
            response = self.http_client.get(url)
            data = response.json()
            data = data.get("feed", {}).get("entry", [])
            # 有可能只有一条
            if isinstance(data, dict):
                data = [data]
            self.logger.info(f"get appstore reviews, page: {page}, count: {len(data)}")

            # 如果没有评论内容，则跳过
            if len(data) == 0:
                break

            for entry in data:
                review = {
                    "id": entry.get("id", {}).get("label", ""),
                    "user_uri": entry.get("author", {}).get("uri", {}).get("label", ""),
                    "user_name": entry.get("author", {}).get("name", {}).get("label", ""),
                    "user_label": entry.get("author", {}).get("label", ""),
                    "title": entry.get("title", {}).get("label", ""),
                    "content": entry.get("content", {}).get("label", ""),
                    "rating": entry.get("im:rating", {}).get("label", ""),
                    "version": entry.get("im:version", {}).get("label", ""),
                    "date": entry.get("updated", {}).get("label", ""),
                    "link": entry.get("link", {}).get("attributes", {}).get("href", ""),
                    "country": country,
                }
                reviews.append(review)

            if len(reviews) >= limit:
                break
            page += 1
        return reviews[:limit]

    def get_app_details(self, id: str, limit: int = 10) -> list[dict]:
        """
        获取AppStore上的应用详情
        :param id: AppStore上的应用ID，也可以是开发者ID，可获得该开发者下的所有App的详情
        :param limit: 获取的应用数量，默认10条
        :return: 应用详情，一个字典，包含应用的相关信息
        """
        url = f"https://itunes.apple.com/lookup?id={id}&entity=software&limit={limit}"
        response = self.http_client.get(url)
        data = response.json()
        data = data.get("results", [])
        if len(data) == 0:
            return []

        results = []
        for item in data:
            app_details = self._convert_to_app_details(item)
            app_id = app_details.get("app_id", "")
            if not app_id or str(app_id).strip() == "":
                continue
            results.append(app_details)
        return results

    def _convert_to_app_details(self, app_details: dict) -> dict:
        """
        将AppStore上的应用详情转换为一个字典
        :param app_details: AppStore上的应用详情，一个字典
        :return: 应用详情，一个字典，包含应用的相关信息
        """
        app_details = {
            "app_id": app_details.get("trackId", ""),
            "app_name": app_details.get("trackName", ""),
            "censored_name": app_details.get("trackCensoredName", ""),
            "primary_genre_name": app_details.get("primaryGenreName", ""),
            "developer_id": app_details.get("artistId", ""),
            "developer_name": app_details.get("artistName", ""),
            "developer_url": app_details.get("artistViewUrl", ""),
            "screenshot_urls": app_details.get("screenshotUrls", []),
            "app_url": app_details.get("trackViewUrl", ""),
            "content_advisory_rating": app_details.get("contentAdvisoryRating", ""),
            "average_user_rating": app_details.get("averageUserRating", ""),
            "genres": app_details.get("genres", []),
            "price": app_details.get("price", ""),
            "formatted_price": app_details.get("formattedPrice", ""),
            "bundle_id": app_details.get("bundleId", ""),
            "is_vpp_device_based_licensing_enabled": app_details.get("isVppDeviceBasedLicensingEnabled", False),
            "release_date": app_details.get("releaseDate", ""),
            "release_notes": app_details.get("releaseNotes", ""),
            "seller_name": app_details.get("sellerName", ""),
            "current_version_release_date": app_details.get("currentVersionReleaseDate", ""),
            "version": app_details.get("version", ""),
            "currency": app_details.get("currency", ""),
            "description": app_details.get("description", ""),
            "average_user_rating_for_current_version": app_details.get("averageUserRatingForCurrentVersion", ""),
            "user_rating_count_for_current_version": app_details.get("userRatingCountForCurrentVersion", ""),
            "website_url": app_details.get("sellerUrl", ""),
            "language_codes_iso2a": app_details.get("languageCodesISO2A", []),
            "file_size_bytes": app_details.get("fileSizeBytes", ""),
            "track_content_rating": app_details.get("trackContentRating", ""),
            "minimum_os_version": app_details.get("minimumOsVersion", ""),
            "user_rating_count": app_details.get("userRatingCount", ""),
            "icon_url_60": app_details.get("artworkUrl60", ""),
            "icon_url_100": app_details.get("artworkUrl100", ""),
            "icon_url_512": app_details.get("artworkUrl512", ""),
            "is_game_center_enabled": app_details.get("isGameCenterEnabled", False),
            "advisories": app_details.get("advisories", []),
            "supported_devices": app_details.get("supportedDevices", []),
        }
        return app_details

    def search_app_details(self, keyword: str, country: str = "us", limit: int = 5) -> list[dict]:
        """
        搜索API：https://developer.apple.com/library/archive/documentation/AudioVideo/Conceptual/iTuneSearchAPI/Searching.html#//apple_ref/doc/uid/TP40017632-CH5-SW1

        搜索AppStore上的应用详情
        :param keyword: 搜索关键词
        :param country: 国家，例如"us"表示美国，"cn"表示中国
        :param limit: 获取的应用数量，默认5条
        :return: 应用详情列表，每个应用详情是一个字典，包含应用的相关信息
        """
        country = country.lower()

        url = f"https://itunes.apple.com/search?term={keyword}&country={country}&entity=software&limit={limit}"
        response = self.http_client.get(url)
        data = response.json()
        data = data.get("results", [])
        results = []
        for item in data:
            app_details = self._convert_to_app_details(item)
            app_id = app_details.get("app_id", "")
            if not app_id or str(app_id).strip() == "":
                continue
            results.append(app_details)
        return results

    def get_app_rank(self, country: str = "us", feed: str = "top-free", limit: int = 10) -> list[dict]:
        """
        获取AppStore上的应用排名
        :param country: 国家，例如"us"表示美国，"cn"表示中国
        :param feed: 应用类型，例如"top-free"表示免费应用，"top-paid"表示付费应用
        :param limit: 获取的应用数量，默认10条
        :return: 应用排名列表，每个应用排名是一个字典，包含应用的相关信息
        """
        country = country.lower()
        url = f"https://rss.marketingtools.apple.com/api/v2/{country}/apps/{feed}/{limit}/apps.json"
        response = self.http_client.get(url)
        data = response.json()
        data = data.get("feed", {}).get("results", [])
        return [self._convert_to_app_rank_details(free_app_details) for free_app_details in data]

    def _convert_to_app_rank_details(self, free_app_details: dict) -> dict:
        """
        将AppStore上的免费应用详情转换为一个字典
        :param free_app_details: AppStore上的免费应用详情，一个字典
        :return: 免费应用详情，一个字典，包含应用的相关信息
        """
        free_app_details = {
            "app_id": free_app_details.get("id", ""),
            "app_name": free_app_details.get("name", ""),
            "developer_name": free_app_details.get("artistName", ""),
            "kind": free_app_details.get("kind", ""),
            "icon_url_100": free_app_details.get("artworkUrl100", ""),
            "release_date": free_app_details.get("releaseDate", ""),
            "app_url": free_app_details.get("url", ""),
            "genres": free_app_details.get("genres", ""),
        }
        return free_app_details
