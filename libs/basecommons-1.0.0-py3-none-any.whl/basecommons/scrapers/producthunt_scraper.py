#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-11-02 11:28.
# @author Horace

import logging
import time
from abc import ABC, abstractmethod
from datetime import datetime

from basecommons.utils import dict_utils
from basecommons.utils.encode_utils import encode_params

g_logger = logging.getLogger(__name__)


class ProductHuntScraper(ABC):
    """ Product Hunt 爬虫 """

    def __init__(self, leaderboard_daily_page_sha256_hash: str, products_page_layout_sha256_hash: str, post_page_comments_sha256_hash: str,
                 product_about_page_sha256_hash: str, product_page_launching_today_sha256_hash: str, leaderboard_weekly_page_sha256_hash: str,
                 leaderboard_monthly_page_sha256_hash: str, leaderboard_yearly_page_sha256_hash: str, sleep_seconds_per_page: int = 1,
                 sleep_seconds_per_detail: int = 1, logger=None, error_print_details: bool = False, headers: dict = None):
        """
        Product Hunt 爬虫
        :param leaderboard_daily_page_sha256_hash: 应用列表的 sha256Hash
        :param products_page_layout_sha256_hash: 应用详情的 sha256Hash
        :param post_page_comments_sha256_hash: 应用评论的 sha256Hash
        :param product_about_page_sha256_hash: 应用关于页面的 sha256Hash
        :param product_page_launching_today_sha256_hash: 应用发布相关信息的 sha256Hash
        :param sleep_seconds_per_page: 每一页睡眠的时间
        :param logger: 日志记录器
        :param error_print_details: 是否打印错误详情
        :param headers: 请求头
        """
        self.logger = logger if logger is not None else g_logger
        self.error_print_details = error_print_details
        self.headers = headers or {
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "accept-language": "zh-CN,zh;q=0.9,ja;q=0.8,en;q=0.7",
            "cache-control": "no-cache",
            "pragma": "no-cache",
            "cookie": "_ga=GA1.1.1331163549.1754385078; ajs_anonymous_id=e6e43e57-8c01-49ff-9d37-42128f905956; intercom-id-fe4ce68d4a8352909f553b276994db414d33a55c=a61d2e02-c048-4e93-b3a4-2cd6c717de58; intercom-device-id-fe4ce68d4a8352909f553b276994db414d33a55c=9bc5f88f-986d-437c-a2b4-31ffcd0b478a; visitor_id=01c2e87b-dee5-4887-a3e0-3c00d3255765; track_code=a6ac5ac674; first_visit=1755503741; first_referer=https://vocalbeats.sg.larksuite.com/; producthunt.reset=1.0; ajs_user_id=8885021; intercom-session-fe4ce68d4a8352909f553b276994db414d33a55c=; __cf_bm=ixqe4f.sY1gPc88LelsIueFW1b2LpiIwxo4kXvWJKeA-1755829878-1.0.1.1-vJxcFbiHV1cj9p7HsqKUjXBWGTcpMdGq_6fvDUjyyp4gM2.y9lo5_stJLAY4ALcOITw.EjFwllOsBcQEQ09Nf0l3DJ4fhWWDKti5KlcQ9.Q; _ga_WZ46833KH9=GS2.1.s1755828896$o11$g1$t1755829896$j60$l0$h0; csrf_token=_zokqWH8kWvsagZYLhc5TA3DGkY0zbiVgdbHJZSF6cuZSOSO2SlW92E6nUneCEnfd11Dj9FS9SpLuyHLTiv7mQ; _producthunt_session_production=yW271Va0UqDfjVCOIQtFp6R6tAWIckZ8xEs96l%2F8CiRQjKpbb6HDatCOqpvc2%2FPs7Wp2J5z8oNbEppr2UNKtFqNNdH8RxJB2yu5nr0iqPdREUrLp3dKQk5u9ooWPOdf7HEh0ZlT0Ci6PlQpiSBBMERdeqXaW09rkAInAZ%2FCtyDQUNVMjwa46Ku6%2FQaUsqzlI63WdPjtdHrqN1efuoywUv%2F9g8Mkm9XRoz5SFbp9lC5HbzJw5hrwxKCCkdGkArWL2%2BrsLuWuOzQ%2BybTHO4au0udwyqSZdaOrj8xKN7y5hNAgbFg%2BuidcqPgQCdBx6qNEfoc5bZ%2FULhBC7fhdfAg%3D%3D--umedR2aIe46OETY7--CZB0C7fNNiaq4Hqj84EF4Q%3D%3D; _dd_s=aid=b5f38b22-4f31-4694-b61d-eb605e12dff0&rum=0&expire=1755830796316",
            "priority": "u=0, i'",
            "sec-ch-ua": "\"Not;A=Brand\";v=\"99\", \"Google Chrome\";v=\"139\", \"Chromium\";v=\"139\"'",
            "sec-ch-ua-mobile": "?0'",
            "sec-ch-ua-platform": "\"macOS\"'",
            "sec-fetch-dest": "document'",
            "sec-fetch-mode": "navigate'",
            "sec-fetch-site": "none'",
            "sec-fetch-user": "?1'",
            "upgrade-insecure-requests": "1'",
            "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36'"
        }
        # 应用列表的 sha256Hash
        self.leaderboard_daily_page_sha256Hash = leaderboard_daily_page_sha256_hash
        # 应用详情的 sha256Hash
        self.products_page_layout_sha256_hash = products_page_layout_sha256_hash
        # 应用评论的 sha256Hash
        self.post_page_comments_sha256Hash = post_page_comments_sha256_hash
        # 每一页睡眠的时间
        self.sleep_seconds_per_page = sleep_seconds_per_page
        # 应用关于页面的 sha256Hash
        self.product_about_page_sha256_hash = product_about_page_sha256_hash
        # 应用发布相关信息的 sha256Hash
        self.product_page_launching_today_sha256_hash = product_page_launching_today_sha256_hash
        # 应用周榜的 sha256Hash
        self.leaderboard_weekly_page_sha256_hash = leaderboard_weekly_page_sha256_hash
        # 应用月榜的 sha256Hash
        self.leaderboard_monthly_page_sha256_hash = leaderboard_monthly_page_sha256_hash
        # 应用年榜的 sha256Hash
        self.leaderboard_yearly_page_sha256_hash = leaderboard_yearly_page_sha256_hash
        # 每一个应用详情页面睡眠的时间
        self.sleep_seconds_per_detail = sleep_seconds_per_detail

    def convert_cycle_type(self, cycle_type: str) -> str:
        """
        转换周期类型
        :param cycle_type: 周期类型，可选值：day、week、month、year
        :return: 转换后的周期类型
        """
        if cycle_type == "day":
            return "LeaderboardDailyPage"
        elif cycle_type == "week":
            return "LeaderboardWeeklyPage"
        elif cycle_type == "month":
            return "LeaderboardMonthlyPage"
        elif cycle_type == "year":
            return "LeaderboardYearlyPage"
        return "unknown"

    def get_app_list_url(self, cycle: str, week: int = None, date: datetime = datetime.now(), cursor: str = "") -> str:
        """
        根据周期类型、周数和日期获取 Product Hunt 应用列表的 URL
        :param cycle: 周期类型：day、week、month、year
        :param week: 周数，取值 1 ~ 52，仅在 cycle_type 为 LeaderboardWeeklyPage 时有效
        :param date: 日期，默认当前日期
        :param cursor: 游标，用于分页，默认空字符串
        :return: 应用列表的 URL
        """
        if cycle == "day":
            variables = encode_params(f'{{"featured":false,"year":{date.year},"month":{date.month},"day":{date.day},"order":"VOTES","cursor":"{cursor}"}}')
            extensions = encode_params(f'{{"persistedQuery":{{"version":1,"sha256Hash":"{self.leaderboard_daily_page_sha256Hash}"}}}}')
        elif cycle == "week":
            variables = encode_params(f'{{"featured":false,"year":{date.year},"week":{week},"order":"VOTES","cursor":"{cursor}"}}')
            extensions = encode_params(f'{{"persistedQuery":{{"version":1,"sha256Hash":"{self.leaderboard_weekly_page_sha256_hash}"}}}}')
        elif cycle == "month":
            variables = encode_params(f'{{"featured":false,"year":{date.year},"month":{date.month},"order":"VOTES","cursor":"{cursor}"}}')
            extensions = encode_params(f'{{"persistedQuery":{{"version":1,"sha256Hash":"{self.leaderboard_monthly_page_sha256_hash}"}}}}')
        elif cycle == "year":
            variables = encode_params(f'{{"featured":false,"year":{date.year},"order":"VOTES","cursor":"{cursor}"}}')
            extensions = encode_params(f'{{"persistedQuery":{{"version":1,"sha256Hash":"{self.leaderboard_yearly_page_sha256_hash}"}}}}')
        else:
            self.logger.error(f"get product hunt apps failed, cycle type error, cycle_type: {cycle}, week: {week}, date: {date}")
            return [], None

        params = f'operationName={self.convert_cycle_type(cycle)}&variables={variables}&extensions={extensions}'
        return f"https://www.producthunt.com/frontend/graphql?{params}"

    def convert_to_apps(self, data: dict, cycle: str, week: int = None, date: datetime = datetime.now()) -> tuple[list[dict], str]:
        """
        转换JSON对象为应用列表
        :param data: JSON对象
        :param cycle: 周期类型，可选值：day、week、month、year
        :param week: 周数，取值 1 ~ 52，仅在 cycle_type 为 LeaderboardWeeklyPage 时有效
        :param date: 日期，默认当前日期
        :return: 应用列表
        """
        apps = []
        data = dict_utils.safe_get(data, "data", "homefeedItems", default={})
        if data is None or len(data) == 0:
            self.logger.error(f"get product hunt apps failed, cycle_type: {cycle}, week: {week}, date: {date}")
            return [], ""

        # 获取下一次游标
        cursor = dict_utils.safe_get(data, "pageInfo", "endCursor", default="")

        # 解析数据
        edges = dict_utils.safe_get(data, "edges", default=[])
        for edge in edges:
            node = dict_utils.safe_get(edge, "node", default={})
            slug = dict_utils.safe_get(node, "product", "slug", default="")
            if slug is None or len(slug) == 0:
                slug = node.get("slug", "")

            # 名字都没有就跳过了
            name = node.get("name", "")
            if name is None or len(name) == 0 or slug is None or len(slug) == 0:
                # 如果是广告，则打印广告日志
                type_name = node.get("__typename", "")
                if type_name == "Ad" or type_name == "GhostAd":
                    self.logger.debug(f"is ad app, name: {name}, tagline: {node.get("tagline")}, node: {node}")
                continue

            app = {
                "id": node.get("id", ""),
                "name": name,
                "slug": slug,
                "tagline": node.get("tagline", ""),
                "latest_score": node.get("latestScore", None),
                "launch_day_score": node.get("launchDayScore", None),
                "created_at": node.get("createdAt", ""),
                "daily_rank": node.get("dailyRank", None),
                "weekly_rank": node.get("weeklyRank", None),
                "monthly_rank": node.get("monthlyRank", None),
                "comments_count": node.get("commentsCount", None),
                "product_url": f"https://www.producthunt.com/products/{slug}",
                "topics": [dict_utils.safe_get(topic, "node", "name", default="") for topic in dict_utils.safe_get(node, "topics", "edges", default=[])],
            }
            apps.append(app)
        return apps, cursor

    def get_app_detail_url(self, slug: str) -> dict:
        """
        获取指定应用的详情 URL
        :param slug: 应用的 slug
        :return: 应用详情 URL
        """
        variables = encode_params(f'{{"slug":"{slug}","includeAlternatives":true,"includeLegacyAlternatives":false}}')
        extensions = encode_params(f'{{"persistedQuery":{{"version":1,"sha256Hash":"{self.products_page_layout_sha256_hash}"}}}}')
        params = f'operationName=ProductsPageLayout&variables={variables}&extensions={extensions}'
        return f"https://www.producthunt.com/frontend/graphql?{params}"

    def convert_to_app_detail(self, slug: str, data_object: dict) -> dict:
        """
        转换JSON对象为应用详情
        :param slug: 应用的 slug
        :param data_object: JSON对象
        :return: 应用详情
        """
        data = dict_utils.safe_get(data_object, "data", "product", default={})
        if data is None or len(data) == 0:
            self.logger.error(f"get product hunt app detail failed, slug: {slug}, result: {data_object}")
            return {}

        app_detail = {
            "id": data.get("id", None),
            "slug": slug,
            "website_url": data.get("websiteUrl", ""),
            "ios_url": data.get("iosUrl", ""),
            "android_url": data.get("androidUrl", ""),
            "github_url": data.get("githubUrl", ""),
            "twitter_url": data.get("twitterUrl", ""),
            "facebook_url": data.get("facebookUrl", ""),
            "instagram_url": data.get("instagramUrl", ""),
            "linkedin_url": data.get("linkedinUrl", ""),
            "angellist_url": data.get("angellistUrl", ""),
            "threads_url": data.get("threadsUrl", ""),
            "medium_url": data.get("mediumUrl", ""),
            "tagline": data.get("tagline", ""),
            "followers_count": data.get("followersCount", None),
            "posts_count": data.get("postsCount", None),
            "discussion_url": f"https://www.producthunt.com{dict_utils.safe_get(data, "discussionForum", "path", default="")}",
            "description": data.get("description", ""),
            "reviews_count": data.get("reviewsCount", None),
            "featured_shoutouts_to_count": data.get("featuredShoutoutsToCount", None),
            # "categories": data.get("categories", []),
            "logo_url": f"https://ph-files.imgix.net/{data.get("logoUuid", "")}",
            "launch_state": dict_utils.safe_get(data, "latestLaunch", "launchState", default=""),
            "website_domain": dict_utils.safe_get(data, "latestLaunch", "product", "websiteDomain", default=None),
            "product_state": dict_utils.safe_get(data, "latestLaunch", "productState", default=None),
            "featured": dict_utils.safe_get(data, "latestLaunch", "featured", default=None),
            "featured_at": dict_utils.safe_get(data, "latestLaunch", "featuredAt", default=None),
            "latest_score": dict_utils.safe_get(data, "latestLaunch", "latestScore", default=None),
            "launch_day_score": dict_utils.safe_get(data, "latestLaunch", "launchDayScore", default=None),
        }
        return app_detail

    def get_about_page_url(self, slug: str):
        """
        获取指定应用的关于页面 URL
        :param slug: 应用的 slug
        :return: 应用关于页面 URL
        """
        variables = encode_params(f'{{"productSlug":"{slug}"}}')
        extensions = encode_params(f'{{"persistedQuery":{{"version":1,"sha256Hash":"{self.product_about_page_sha256_hash}"}}}}')
        params = f'operationName=ProductAboutPage&variables={variables}&extensions={extensions}'
        return f"https://www.producthunt.com/frontend/graphql?{params}"

    def convert_to_about_page_info(self, slug: str, data_object: dict) -> dict:
        """
        转换JSON对象为应用关于页面信息
        :param slug: 应用的 slug
        :param data_object: JSON对象
        :return: 应用关于页面信息
        """
        data = dict_utils.safe_get(data_object, "data", "product", default={})
        if data is None or len(data) == 0:
            self.logger.error(f"get product hunt about info failed, slug: {slug}, result: {data_object}")
            return {}

        media_list = [
            {
                "id": item.get("id", ""),
                "url": f"https://ph-files.imgix.net/{item.get("imageUuid", "")}",
                "media_type": item.get("mediaType", ""),
                "original_width": item.get("originalWidth", None),
                "original_height": item.get("originalHeight", None),
            }
            for item in dict_utils.safe_get(data, "media", default=[])
        ]
        result = {
            "id": data.get("id", ""),
            "slug": slug,
            "name": data.get("name", ""),
            "media_list": media_list,
            "screenshots": dict_utils.safe_get(data, "screenshots", "edges", default=[]),
        }
        return result

    def get_launching_info_url(self, slug: str):
        """
        获取指定应用的发布相关信息 URL
        :param slug: 应用的 slug
        :return: 应用发布相关信息 URL
        """
        variables = encode_params(
            f'{{"commentsListSubjectThreadsCursor":null,"commentsThreadRepliesCursor":"","includeThreadForCommentId":null,"commentsListSubjectThreadsLimit":7,"commentsListSubjectFilter":null,"order":"DEFAULT","excludeThreadForCommentId":null,"commentsListSubjectThreadsPage":1,"slug":"{slug}"}}')
        extensions = encode_params(f'{{"persistedQuery":{{"version":1,"sha256Hash":"{self.product_page_launching_today_sha256_hash}"}}}}')
        params = f'operationName=ProductPageLaunchingToday&variables={variables}&extensions={extensions}'
        return f"https://www.producthunt.com/frontend/graphql?{params}"

    def convert_to_launching_info(self, slug: str, data: dict):
        """
        转换JSON对象为应用发布相关信息
        :param slug: 应用的 slug
        :param data: JSON对象
        :return: 应用发布相关信息
        """
        data = dict_utils.safe_get(data, "data", "product", default={})
        makers = [
            {
                "id": maker.get("id", ""),
                "name": maker.get("name", ""),
                "headline": maker.get("headline", ""),
                "username": maker.get("username", ""),
                "avatarUrl": maker.get("avatarUrl", ""),
                "homepage": f"https://www.producthunt.com/@{maker.get("username", "")}"
            }
            for maker in dict_utils.safe_get(data, "latestLaunch", "makers", default=[])
        ]

        built_with = [
            {
                "id": built_with.get("id", ""),
                "slug": dict_utils.safe_get(built_with, "product", "slug", default=""),
                "name": dict_utils.safe_get(built_with, "product", "name", default=""),
                "tagline": dict_utils.safe_get(built_with, "product", "tagline", default=""),
                "product_url": f"https://www.producthunt.com{dict_utils.safe_get(built_with, "product", "path", default='')}",
                "logo_url": f"https://ph-files.imgix.net/{dict_utils.safe_get(built_with, "product", "logoUuid", default='')}",
                "overall_experience": built_with.get("overallExperience", ""),
            }
            for built_with in dict_utils.safe_get(data, "latestLaunch", "detailedReviews", default=[])
        ]
        result = {
            "slug": slug,
            "makers": makers,
            "built_with": built_with,
        }
        return result

    def get_app_comments_url(self, slug: str, limit: int = 100) -> str:
        variables = encode_params(
            f'{{"commentsListSubjectThreadsCursor":"","commentsListSubjectThreadsPage":null,"commentsThreadRepliesCursor":"","order":"DATE","slug":"{slug}","includeThreadForCommentId":null,"commentsListSubjectThreadsLimit":{limit},"commentsListSubjectFilter":null,"excludeThreadForCommentId":null}}')
        extensions = encode_params(f'{{"persistedQuery":{{"version":1,"sha256Hash":"{self.post_page_comments_sha256Hash}"}}}}')
        params = f'operationName=PostPageComments&variables={variables}&extensions={extensions}'
        return f"https://www.producthunt.com/frontend/graphql?{params}"

    def convert_node_comments(self, node: dict) -> dict:
        """
        获取节点的所有评论，将有层次结构的评论转换为一维列表
        :param node: 节点
        :return: 评论列表
        """
        comment = {
            "id": node.get("id", ""),
            "replies_count": node.get("repliesCount", None),
            "votes_count": node.get("votesCount", None),
            "user": {
                "id": dict_utils.safe_get(node, "user", "id", default=""),
                "name": dict_utils.safe_get(node, "user", "name", default=""),
                "username": dict_utils.safe_get(node, "user", "username", default=""),
                "avatar_url": dict_utils.safe_get(node, "user", "avatarUrl", default=""),
            },
            "content": node.get("bodyHtml", ""),
            "url": node.get("url", ""),
            "created_at": node.get("createdAt", ""),
            "badges": node.get("badges", []),
        }

        # 如果有回复，则递归获取回复的评论
        replies_list = dict_utils.safe_get(node, "replies", "edges", default=[])
        if len(replies_list) > 0:
            replies = []
            for reply in replies_list:
                reply_node = reply.get("node", {})
                reply_comments = self.convert_node_comments(reply_node)
                replies.append(reply_comments)
            comment["replies"] = replies
        return comment

    def convert_to_comments(self, slug: str, limit: int, data: dict) -> list[dict]:
        # 如果发生错误，则抛出异常
        if data.get("errors", []) is not None and len(data.get("errors", [])) > 0:
            self.logger.error(f"get product hunt app comments error, slug: {slug}, limit: {limit}")
            return []
        comments = dict_utils.safe_get(data, "data", "post", "threads", "edges", default=[])

        result = []
        for comment in comments:
            node = comment.get("node", {})
            node_comments = self.convert_node_comments(node)
            result.append(node_comments)
        return result

    async def __get_apps(self, cycle: str, week: int = None, date: datetime = datetime.now(), cursor: str = "") -> tuple[list, str]:
        """
        获取指定日期的 Product Hunt 应用列表
        :param cycle: 周期类型：day、week、month、year
        :param week: 周数，取值 1 ~ 52，仅在 cycle_type 为 week 时有效
        :param date: 日期
        :param cursor: 游标
        :return: 应用列表, 游标
        """
        if cursor is None:
            return [], None

        apps_json_object = await self.get_apps_by_url(self.get_app_list_url(cycle, week, date, cursor))
        apps, next_cursor = self.convert_to_apps(apps_json_object, cycle, week, date)
        self.logger.info(f"get product hunt apps by page, cycle_type: {cycle}, week: {week}, date: {date}, flag: {cursor}, count: {len(apps)}")
        return apps, next_cursor

    async def get_apps(self, cycle: str, week: int = None, date: datetime = datetime.now(), limit: int = 10) -> list[dict]:
        """
        获取指定日期的所有 Product Hunt 应用
        :param cycle: 周期类型：day、week、month、year
        :param week: 周数，取值 1 ~ 52，仅在 cycle_type 为 LeaderboardWeeklyPage 时有效
        :param date: 日期
        :param limit: 限制数量
        :return: 应用列表
        """
        apps = []
        cursor = ""
        while True:
            temp_apps, cursor = await self.__get_apps(cycle=cycle, week=week, date=date, cursor=cursor)
            if not temp_apps or len(temp_apps) == 0:
                break
            apps.extend(temp_apps)
            if len(apps) >= limit:
                break
            # 避免请求过快
            time.sleep(self.sleep_seconds_per_page)
        apps = apps[:limit]

        # 获取应用详情
        for app in apps:
            app_detail = await self.get_app_detail(app.get("slug", ""))
            app.update(app_detail)
            # 避免请求过快
            time.sleep(self.sleep_seconds_per_detail)
        return apps

    async def get_app_detail(self, slug: str) -> dict:
        """
        获取指定应用的详情
        :param slug: 应用的 slug
        :return: 应用详情
        """
        app_detail_json_object = await self.get_app_detail_by_url(self.get_app_detail_url(slug))
        app_detail = self.convert_to_app_detail(slug, app_detail_json_object)

        # 获取应用关于页面的信息，包含应用的截图和媒体列表
        about_page_info = await self.get_about_page_info(slug)
        if about_page_info is not None and len(about_page_info) > 0:
            app_detail.update(about_page_info)

        # 获取发布相关信息
        launching_info = await self.get_launching_info(slug)
        if launching_info is not None and len(launching_info) > 0:
            app_detail.update(launching_info)

        # 获取产品介绍
        comments = await self.get_app_comments(slug=slug, limit=1)
        introduction = ""
        if len(comments) > 0:
            comment = comments[0]
            if "maker" in comment.get("badges", []):
                introduction = comment.get("content", "")
        app_detail["introduction"] = introduction

        self.logger.info(f"get app detail success, slug: {slug}")
        return app_detail

    async def get_about_page_info(self, slug: str) -> dict:
        """
        获取指定应用的关于页面信息
        :param slug: 应用的 slug
        :return: 应用关于页面信息
        """
        result = {}
        try:
            about_page_info_json_object = await self.get_about_page_info_by_url(self.get_about_page_url(slug))
            result = self.convert_to_about_page_info(slug, about_page_info_json_object)
        except Exception as e:
            self.logger.error(f"get product hunt about info failed, slug: {slug}, error: {e}")
        return result

    async def get_launching_info(self, slug: str) -> dict:
        """
        获取指定应用的发布相关信息
        :param slug: 应用的 slug
        :return: 应用发布相关信息
        """
        result = {}
        try:
            launching_info_json_object = await self.get_launching_info_by_url(self.get_launching_info_url(slug))
            result = self.convert_to_launching_info(slug, launching_info_json_object)
        except Exception as e:
            self.logger.error(f"get product hunt app launching info failed, slug: {slug}, err: {e}")
        return result

    async def get_app_comments(self, slug: str, limit: int = 100) -> list[dict]:
        """
        获取指定应用的评论
        :param slug: 应用的 slug
        :param limit: 限制数量
        :return: 应用评论列表
        """
        try:
            app_comments_json_object = await self.get_app_comments_by_url(self.get_app_comments_url(slug, limit))
            comments = self.convert_to_comments(slug, limit, app_comments_json_object)
            self.logger.info(f"get product hunt app comments success, slug: {slug}, limit: {limit}, length: {len(comments)}")
            return comments
        except (KeyError, TypeError, AttributeError):
            self.logger.error(f"get product hunt app comments failed, slug: {slug}, limit: {limit}")
            return []

    @abstractmethod
    async def init(self):
        """
        初始化Scraper，加载必要的资源
        :return:
        """
        pass

    @abstractmethod
    async def get_apps_by_url(self, url: str) -> dict:
        """
        根据URL获取应用列表
        :param url: 应用列表URL
        :return: 应用列表JSON对象
        """
        pass

    @abstractmethod
    async def get_app_detail_by_url(self, url: str) -> dict:
        """
        根据URL地址获取应用详情
        :param url: 应用详情URL
        :return: 应用详情JSON对象
        """
        pass

    @abstractmethod
    async def get_about_page_info_by_url(self, url: str) -> dict:
        """
        根据URL地址获取应用关于页面信息
        :param url: 应用关于页面URL
        :return: 应用关于页面JSON对象
        """

    @abstractmethod
    async def get_launching_info_by_url(self, url: str) -> dict:
        """
        根据URL地址获取应用发布相关信息
        :param url: 应用发布相关信息URL
        :return: 应用发布相关信息JSON对象
        """
        pass

    @abstractmethod
    async def get_app_comments_by_url(self, url: str) -> dict:
        """
        根据URL地址获取应用评论
        :param url: 应用评论URL
        :return: 应用评论JSON对象
        """
        pass

    @abstractmethod
    async def close(self):
        """
        关闭Scraper，释放资源
        :return:
        """
        pass
