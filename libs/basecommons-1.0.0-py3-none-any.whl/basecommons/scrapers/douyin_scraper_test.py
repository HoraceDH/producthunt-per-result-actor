#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-08-02 16:46.
# @author Horace
import logging

from basecommons.logger import init_logging
from basecommons.utils.json_utils import to_json_string
from douyin_scraper import DouyinScraper

logger = logging.getLogger(__name__)

if __name__ == '__main__':
    init_logging()

    # hot_rank_list = HotRankList(update_time=time.time(), hot_rank_list=[HotRankItem(1, "项目1", 1000)])
    # logger.info(f"json_str: {to_json_string(hot_rank_list)}")

    douyin_scraper = DouyinScraper()
    # success, hot_rank_list = asyncio.run(douyin_scraper.get_hot_rank_list())
    # logger.info(f"douyin hot rank, success: {success}, hot_rank_list: {to_json_string(hot_rank_list)}")

    # success, media_objects = asyncio.run(douyin_scraper.get_media_objects(keyword="逻辑训练卡", headless=False, chromium=False, timeout=150000 * 1000, count=100))
    # logger.info(f"douyin media objects, success: {success}, length: {len(media_objects)}, media_objects: {json.dumps(media_objects)}")

    video_infos = douyin_scraper.get_video_infos(keyword="春节假期", limit=20)
    logger.info(f"get douyin video infos, length: {len(video_infos)}, video_infos: {to_json_string(video_infos)}")
