#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-08-02 16:14.
# @author Horace
import logging
import time
import traceback
from typing import List, Any

from basecommons.beans import HotRankList
from basecommons.clients.http_client import HttpClient
from basecommons.scrapers.hot_rank_scraper import HotRankScraper
from basecommons.utils.encode_utils import encode_params
from basecommons.utils.json_utils import to_json_object
from basecommons.utils.list_utils import get_list_element
from basecommons.utils.time_utils import get_current_timestamp

g_logger = logging.getLogger(__name__)


class DouyinScraper:
    """
    抖音数据爬取器
    """

    def __init__(self, logger=None):
        self.logger = logger if logger is not None else g_logger
        self.monitor_urls = ["https://www.douyin.com/aweme/v1/web/general/search/stream", "https://www.douyin.com/aweme/v1/web/general/search/single"]
        self.hot_rank_scraper = HotRankScraper(logger=self.logger)
        self.http_client = HttpClient(logger=self.logger)

    async def get_hot_rank_list(self) -> tuple[bool, HotRankList]:
        """
        爬取抖音热榜信息
        :return: (success, hot_rank_list)
        """
        return await self.hot_rank_scraper.get_douyin_hot_rank_list()

    def __convert_to_video_infos(self, json_object_str) -> list[dict]:
        """
        转换响应对象为视频信息对象
        :param json_object_str: 响应对象字符串
        :return: 视频信息对象
        """
        self.logger.debug(f"convert response object to video info object, json_object_str: {json_object_str}")
        if json_object_str is None or json_object_str.isspace():
            return None
        json_object = to_json_object(json_object_str)
        if json_object is None:
            return None
        if "status_code" not in json_object:
            return None
        if json_object["status_code"] != 0:
            return None
        if "data" not in json_object:
            return None

        data_list = json_object["data"]
        media_objects = []
        for data in data_list:
            if "aweme_info" not in data:
                continue

            aweme_info_object = data["aweme_info"]
            id = aweme_info_object.get("aweme_id", "")
            desc = aweme_info_object.get("desc", "")
            create_time = aweme_info_object.get("create_time", 0)
            author_object = aweme_info_object.get("author", {})
            music_object = aweme_info_object.get("music", {})
            video_object = aweme_info_object.get("video", {})

            media_object = {
                "id": id,
                "cover": get_list_element(video_object.get("cover", {}).get("url_list", []), 0),
                "url": f"https://www.douyin.com/video/{id}",
                "desc": desc,
                "author": {
                    "id": author_object.get("uid", ""),
                    "short_id": author_object.get("short_id", ""),
                    "nickname": author_object.get("nickname", ""),
                    "signature": author_object.get("signature", ""),
                    "avatar_larger": get_list_element(author_object.get("avatar_larger", {}).get("url_list", []), 0),
                    "avatar_thumb": get_list_element(author_object.get("avatar_thumb", {}).get("url_list", []), 0),
                    "avatar_medium": get_list_element(author_object.get("avatar_medium", {}).get("url_list", []), 0),
                    "aweme_count": author_object.get("aweme_count", 0),
                    "following_count": author_object.get("following_count", 0),
                    "follower_count": author_object.get("follower_count", 0),
                    "favoriting_count": author_object.get("favoriting_count", 0),
                    "total_favorited": author_object.get("total_favorited", 0),
                },
                "music": {
                    "id": music_object.get("id_str", ""),
                    "title": music_object.get("title", ""),
                    "author": music_object.get("author", ""),
                    "album": music_object.get("album", ""),
                    "cover_hd": get_list_element(music_object.get("cover_hd", {}).get("url_list", []), 0),
                    "cover_large": get_list_element(music_object.get("cover_large", {}).get("url_list", []), 0),
                    "cover_medium": get_list_element(music_object.get("cover_medium", {}).get("url_list", []), 0),
                    "cover_thumb": get_list_element(music_object.get("cover_thumb", {}).get("url_list", []), 0),
                    "play_url": get_list_element(music_object.get("play_url", {}).get("url_list", []), 0),
                    "source_platform": music_object.get("source_platform", 0),
                    "duration": music_object.get("duration", 0),
                    "owner_id": music_object.get("owner_id", 0),
                },
                "video": {
                    "format": video_object.get("format", ""),
                    "height": video_object.get("height", 0),
                    "width": video_object.get("width", 0),
                    "cover": get_list_element(video_object.get("cover", {}).get("url_list", []), 0),
                    "dynamic_cover": get_list_element(video_object.get("dynamic_cover", {}).get("url_list", []), 0),
                    "origin_cover": get_list_element(video_object.get("origin_cover", {}).get("url_list", []), 0),
                    "video_url": self.__get_video_url(video_object.get("play_addr", {}).get("url_list", [])),
                    "download_url": self.__get_video_url(video_object.get("download_addr", {}).get("url_list", [])),
                    "ratio": video_object.get("ratio", ""),
                    "duration": video_object.get("duration", 0),
                    "cdn_url_expired": video_object.get("cdn_url_expired", 0),
                },
                "text_extra": aweme_info_object.get("text_extra", {}),
                "statistics": aweme_info_object.get("statistics", {}),
                "share_info": aweme_info_object.get("share_info", {}),
                "create_time": create_time,
            }
            media_objects.append(media_object)
        return media_objects

    def __get_video_url(self, url_list):
        """
        获取视频播放地址
        :param url_list: 视频播放地址列表
        :return: 视频播放地址
        """
        result = get_list_element(url_list, 0)
        for url in url_list[1:]:
            if "www.douyin.com/aweme" in url:
                result = url
        return result

    async def __handle_response(self, response, media_objects):
        """
        处理搜索响应事件
        :param response: 响应对象
        :param media_objects: 处理结果存储到媒体对象列表中
        :return:
        """
        for monitor_url in self.monitor_urls:
            if monitor_url in response.url:
                try:
                    # 获取响应文本
                    response_text = await response.text()
                    if response_text is None or response_text == "":
                        self.logger.warning(f"received response failed, response is none, url: {response.url}")
                        return

                    json_array = response_text.split("\r\n")
                    for json_object_str in json_array:
                        temp_media_objects = self.__convert_to_video_infos(json_object_str)
                        if temp_media_objects:
                            media_objects.extend(temp_media_objects)
                except Exception as e:
                    self.logger.error(f"handle douyin response failed, error: {e}, traceback: {traceback.format_exc()}")

    async def get_media_objects(self, keyword: str, count: int = 20, headless: bool = True, timeout: int = 15 * 1000, chromium=False) -> tuple[bool, List[Any]]:
        """
        获取抖音视频信息
        :param keyword: 搜索关键词
        :param count: 搜索数量
        :param headless: 是否无头浏览器
        :param timeout: 超时时间，毫秒
        :param chromium: 是否使用chromium浏览器
        :return: success, media_objects
        """
        from playwright.async_api import async_playwright
        if headless is None:
            headless = False

        self.logger.info(f"start get douyin media objects, keyword: {keyword}, count: {count}, timeout: {timeout}ms")
        media_objects = []
        async with async_playwright() as playwright:
            if chromium:
                browser = await playwright.chromium.launch(
                    headless=headless,
                    args=[],
                )
            else:
                browser = await playwright.webkit.launch(
                    headless=headless,
                    args=[],
                )
            context = await browser.new_context(no_viewport=True, viewport={"width": 1920, "height": 1080})
            page = await context.new_page()
            try:
                search_url = f"https://www.douyin.com/search/{encode_params(keyword)}"
                page.on("response", lambda response: self.__handle_response(response, media_objects))
                await page.goto(search_url)
                self.logger.info(f"open douyin success, wait for data...")

                # 如果达到指定数量或者超时时间，则退出循环
                current_timestamp = get_current_timestamp()
                while len(media_objects) < count and (get_current_timestamp() - current_timestamp) < timeout:
                    # 向上滑动一屏高度
                    await page.evaluate('window.scrollBy(0, window.innerHeight)')
                    # 等待2秒让内容加载
                    await page.wait_for_timeout(1000)

                    # 检测并处理需要登录的场景
                    await self._check_and_handle_login(page)
                    total_count = min(len(media_objects), count)
                    self.logger.info(f"get douyin media objects, keyword: {keyword}, total_count: {total_count}")

                use_time = get_current_timestamp() - current_timestamp
                if use_time >= timeout:
                    self.logger.warning(f"get douyin media objects timeout, keyword: {keyword}, timeout: {timeout}ms, use_time: {use_time}ms")

                media_objects = media_objects[:count]
                self.logger.info(f"get douyin media objects completed, keyword: {keyword}, total_count: {len(media_objects)}")
                return True, media_objects
            except Exception as e:
                self.logger.error(f"get douyin media objects error, keyword: {keyword}, error: {e}, traceback: {traceback.format_exc()}")
                self.logger.info(f"get douyin media objects completed, keyword: {keyword}, total_count: {len(media_objects)}")
                return False, media_objects
            finally:
                try:
                    await page.close()
                    await context.close()
                    await browser.close()
                except:
                    pass

    def get_div_by_full_text(self, target, text_to_match):
        """
        返回页面上文本完全等于 text_to_match 的 div 元素
        """
        # 使用 XPath 全匹配
        locator = target.locator(f'//div[normalize-space(text())="{text_to_match}"]')
        return locator

    async def _check_and_handle_login(self, page):
        """
        检测并处理需要登录的场景，如果出现了登录弹窗，则点击取消按钮并且重新点击搜索按钮
        """
        try:
            # 登录后免费畅享高清视频 的弹窗
            login_panel = page.locator('div[id="login-panel-new"]')
            if login_panel and await login_panel.is_visible(timeout=0.1):
                self.logger.warning(f"login panel visible...")

                # 在login_panel内查找包含"登录后免费畅享高清视频"文字的div
                target_div = login_panel.locator('//div[normalize-space(text())="登录后免费畅享高清视频"]')

                if target_div and await target_div.is_visible(timeout=0.1):
                    # 获取下一个div元素并且点击
                    next_div = target_div.locator("xpath=following-sibling::div[1]")
                    if next_div and await next_div.is_visible(timeout=0.1):
                        await next_div.click()
                        self.logger.warning(f"login panel cancel clicked...")

            # 如果需要拼图
            pintu_panel = page.locator('div[id="captcha_container"]')
            if pintu_panel and await pintu_panel.is_visible(timeout=0.1):
                self.logger.warning(f"pintu panel visible, handle this page...")
                # 重新刷新页面
                await page.reload()

            # 请登录后继续使用 的弹窗
            login_use_div = page.locator('//div[normalize-space(text())="请登录后继续使用"]')
            if login_use_div and await login_use_div.is_visible(timeout=0.1):
                self.logger.warning(f"login dialog visible, handle this page...")
                # 重新刷新页面
                await page.reload()
        except Exception as e:
            self.logger.error(f"check and handle douyin login dialog error, error: {e}, traceback: {traceback.format_exc()}")

    def get_video_infos(self, keyword: str, limit: int = 20) -> list[dict]:
        """
        获取抖音视频信息
        :param keyword: 搜索关键词
        :param limit: 获取视频数量
        :return: video_infos
        """
        single_url = "https://www.douyin.com/aweme/v1/web/general/search/single/?device_platform=webapp&aid=6383&channel=channel_pc_web&search_channel=aweme_general&enable_history=1&search_source=normal_search&query_correct_type=1&is_filter_search=0&from_group_id=&disable_rs=0&need_filter_settings=0&list_type=multi&pc_search_top_1_params=%7B%22enable_ai_search_top_1%22%3A1%7D&search_id=2025110421544578CD7A592D4DBB15FDAC&update_version_code=170400&pc_client_type=1&pc_libra_divert=Mac&support_h265=1&support_dash=1&cpu_core_num=8&version_code=190600&version_name=19.6.0&cookie_enabled=true&screen_width=2560&screen_height=1440&browser_language=zh-CN&browser_platform=MacIntel&browser_name=Chrome&browser_version=142.0.0.0&browser_online=true&engine_name=Blink&engine_version=142.0.0.0&os_name=Mac+OS&os_version=10.15.7&device_memory=8&platform=PC&downlink=1.45&effective_type=4g&round_trip_time=100&webid=7562897359484225062&uifid=94323c0887b37f94f50ac5417d2d415b74fcf5f1106c230e40c326c63b00b6633ebc63034b67739db9a9bf4a8e1b9e6f2a9bd4d0d29f62121acd1f3308f05694afd1e8c224d4b62bb1fd5175fee588ae7b38ec9e04502aee4e8d70552d3ee9a69f97d0cf10b2155f64f230339e33960e18c840956b26ea6838834984c4155964d6ff4c18abaa6ba8c1752fa5284f16ca07a90c5f58f61cfbafd366a24ad16ff7&msToken=CsslI07oHmNn_Q_VlDTDN_WHgt-2o6eXswY5i0mdyV3S5zmjV7-ss1EUIHFD5yf5rkeCfxVI18oMgP_zhJPdgcy3pc1TmHJRVdNjjKtMxbeQKXsabiDjgZsjTRfsFXbd0_6vEzBqejD6f-1hwWNtLQibMvUJu1GPAqDwdtQgknqXL_eb3Uw_Qw%3D%3D&a_bogus=mv0VkwyEdd%2FcadKbYOaASX%2FlU6fANBuyxeTOSFAlHOiocZlc4bPTPntZjoK14nWB0Rpwwo1HjVlAYddc0TtsZCHkLmpvSuzRFWOCIWmogqq3alU0ErRMCLDNSJ7bWYkEmQKSJl4vIzQa2dA4DZrwUplyCAJEsOkdQqafdn4Gx9eD6049spZBPwvAGDSFU4rh8tk6HGb%3D"
        headers = {
            "accept": "application/json, text/plain, */*'",
            "accept-language": "zh-CN,zh;q=0.9,ja;q=0.8,en;q=0.7'",
            "priority": "u=1, i'",
            "sec-ch-ua": "\"Chromium\";v=\"142\", \"Google Chrome\";v=\"142\", \"Not_A Brand\";v=\"99\"'",
            "sec-ch-ua-mobile": "?0'",
            "sec-ch-ua-platform": "macOS",
            "sec-fetch-dest": "empty'",
            "sec-fetch-mode": "cors'",
            "sec-fetch-site": "same-origin'",
            "uifid": "94323c0887b37f94f50ac5417d2d415b74fcf5f1106c230e40c326c63b00b6633ebc63034b67739db9a9bf4a8e1b9e6f2a9bd4d0d29f62121acd1f3308f05694afd1e8c224d4b62bb1fd5175fee588ae7b38ec9e04502aee4e8d70552d3ee9a69f97d0cf10b2155f64f230339e33960e18c840956b26ea6838834984c4155964d6ff4c18abaa6ba8c1752fa5284f16ca07a90c5f58f61cfbafd366a24ad16ff7",
            "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36'",
            "cookie": f"enter_pc_once=1; UIFID_TEMP=94323c0887b37f94f50ac5417d2d415b74fcf5f1106c230e40c326c63b00b66376d9f45d568ad3ba2f9bb547fd6071e02f20ca644574d56741fefdd210d0febc4c3beff693c05911d14a699d6cc4c13a; s_v_web_id=verify_mgxn2q50_2lKIjT8u_CTmw_4Fpc_97rb_my9Ui0ihLQeX; hevc_supported=true; fpk1=U2FsdGVkX1+VMNMqxwqtKqkJ07X/txBhbTMMw8pjKtUdz5PUICErayOWRooPbWod0JsofZvOJ/J2mmg4vo+UaA==; fpk2=3ade46e10ab46df1d7d395ddaa715a24; passport_csrf_token=84debe9c4fc015bba8cce0d1394ef1c1; passport_csrf_token_default=84debe9c4fc015bba8cce0d1394ef1c1; __security_mc_1_s_sdk_crypt_sdk=6008f657-43ff-a9f6; bd_ticket_guard_client_web_domain=2; odin_tt=3e24a89e4d75db1fa30d3b0ef70e6209756ecee2e66635109267a4594f6c2eee973773277b8d741df9a5e30d9efd136c9861970d3b9072dc31f66a7a76276fb5cffed04fba7c96d4894a556fc9d2f60f; UIFID=94323c0887b37f94f50ac5417d2d415b74fcf5f1106c230e40c326c63b00b6633ebc63034b67739db9a9bf4a8e1b9e6f2a9bd4d0d29f62121acd1f3308f05694afd1e8c224d4b62bb1fd5175fee588ae7b38ec9e04502aee4e8d70552d3ee9a69f97d0cf10b2155f64f230339e33960e18c840956b26ea6838834984c4155964d6ff4c18abaa6ba8c1752fa5284f16ca07a90c5f58f61cfbafd366a24ad16ff7; dy_swidth=2560; dy_sheight=1440; is_dash_user=1; strategyABtestKey=%221762182229.069%22; SearchResultListTypeChangedManually=%221%22; SEARCH_RESULT_LIST_TYPE=%22multi%22; stream_recommend_feed_params=%22%7B%5C%22cookie_enabled%5C%22%3Atrue%2C%5C%22screen_width%5C%22%3A2560%2C%5C%22screen_height%5C%22%3A1440%2C%5C%22browser_online%5C%22%3Atrue%2C%5C%22cpu_core_num%5C%22%3A8%2C%5C%22device_memory%5C%22%3A8%2C%5C%22downlink%5C%22%3A10%2C%5C%22effective_type%5C%22%3A%5C%224g%5C%22%2C%5C%22round_trip_time%5C%22%3A50%7D%22; download_guide=%223%2F20251104%2F0%22; __ac_signature=_02B4Z6wo00f01WW4sVAAAIDBobwjNlImNbFlmLXAADBnf6; csrf_session_id=5280e618328458e5fae370f9d4f97fa1; home_can_add_dy_2_desktop=%221%22; ttwid=1%7CrdNdIB9ca7lt5gg-jJgPgxNY_nwJXzeC9lmijj8Bu6o%7C1762264786%7C28d032c67b555f3767e3f90448fd83f7b259e1ffe306491e797b0964021a46c5; bd_ticket_guard_client_data=eyJiZC10aWNrZXQtZ3VhcmQtdmVyc2lvbiI6MiwiYmQtdGlja2V0LWd1YXJkLWl0ZXJhdGlvbi12ZXJzaW9uIjoxLCJiZC10aWNrZXQtZ3VhcmQtcmVlLXB1YmxpYy1rZXkiOiJCUEZKaVBWRlV3OE9LZUtvby8zbjRRLzM1WkpKTVJ3VCtiYVcySUczejZzaVJrcEExb2dmRVpYelVmWHdyMDBDRDIrZXRqRm15b1lxOWg4Y0oyMDhVeHc9IiwiYmQtdGlja2V0LWd1YXJkLXdlYi12ZXJzaW9uIjoyfQ%3D%3D; biz_trace_id=4a5afa34; IsDouyinActive=true; bd_ticket_guard_client_data_v2=eyJyZWVfcHVibGljX2tleSI6IkJQRkppUFZGVXc4T0tlS29vLzNuNFEvMzVaSkpNUndUK2JhVzJJRzN6NnNpUmtwQTFvZ2ZFWlh6VWZYd3IwMENEMitldGpGbXlvWXE5aDhjSjIwOFV4dz0iLCJyZXFfY29udGVudCI6InNlY190cyIsInJlcV9zaWduIjoiMVRibmtWUXQvS0loSmEvWUIyVnlWY1dHUEJaMThyR2trdXgwMFBHMnMwbz0iLCJzZWNfdHMiOiIjZWcrei9hRHUycEJhZHVsY3dmbkdUL0xmeVZiNGhUc0hwR2FhVHNUbXlzN1NtU1hNczdUTGJyT0dkaFREIn0%3D"
        }

        headers.update({
            "referer": f"https://www.douyin.com/search/{encode_params(keyword)}"
        })

        offset = 0
        count = 10
        video_infos = []
        for index in range(0, int(limit / count + 10)):
            url = single_url + f"&keyword={encode_params(keyword)}&count={count}&offset={offset}"
            response = self.http_client.get(url=url,headers=headers)
            temp_video_infos = self.__convert_data_to_video_infos(response.text)
            video_infos.extend(temp_video_infos)
            self.logger.info(f"get douyin video infos, offset: {offset}, count: {count}, length: {len(temp_video_infos)}")

            offset += count
            # 如果去重后数量已经足够，则提前退出循环
            video_infos = list({video_info["id"]: video_info for video_info in video_infos}.values())
            if len(video_infos) >= limit:
                break
            time.sleep(3)

        # 根据id字段去重
        return video_infos[:limit]

    def __convert_data_to_video_infos(self, data: str) -> list[dict]:
        """
        解析抖音返回的json数据，转换为视频信息列表
        :param data: 抖音返回的json数据
        :return: 视频信息列表
        """
        json_array_str = data.split("\r\n")
        temp_video_infos = []
        for json_object_str in json_array_str:
            self.__check_web_need_login(json_object_str)
            temp_media_objects = self.__convert_to_video_infos(json_object_str)
            if temp_media_objects:
                temp_video_infos.extend(temp_media_objects)
        return temp_video_infos

    def __check_web_need_login(self, json_object_str: str):
        """
        检查抖音返回的json数据是否需要登录
        :param json_object_str: 抖音返回的json数据
        :return:
        """
        try:
            json_object = to_json_object(json_object_str)
            data = json_object.get("search_nil_info", {}).get("search_nil_type")
            if data and data == "web_need_login":
                self.logger.warning(f"douyin need login...")
        except:
            pass
