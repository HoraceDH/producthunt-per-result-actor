#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-11-05 23:54.
# @author Horace
import logging

logger = logging.getLogger(__name__)


def safe_get(dictionary: dict, *keys, default=None):
    """
    安全获取嵌套字典的值
    :param dictionary: 字典对象
    :param keys: 键的路径，例如 "a", "b", "c" 表示获取 dictionary["a"]["b"]["c"] 的值
    :param default: 默认值
    :return: 获取到的值或默认值
    """
    current = dictionary
    for key in keys:
        if isinstance(current, dict) and key in current:
            current = current[key]
        else:
            return default
    return current
