#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-08-01 15:16.
# @author Horace
import datetime
import logging

from flask.json.provider import DefaultJSONProvider

logger = logging.getLogger(__name__)


class JSONEncoder(DefaultJSONProvider):
    """
    自定义JSON序列化器
    """

    def default(self, obj):
        if isinstance(obj, datetime.datetime):
            return obj.strftime('%Y-%m-%d %H:%M:%S')
        return super().default(obj)
