#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-11-02 20:50.
# @author Horace
import logging

logger = logging.getLogger(__name__)


def query_string_to_dict(query_string: str) -> dict:
    """
    将查询字符串转换为字典
    """
    query_dict = {}
    for item in query_string.split("&"):
        key, value = item.split("=")
        query_dict[key] = value
    return query_dict
