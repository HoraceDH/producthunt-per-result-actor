#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-06-16 00:14.
# @author Horace
import logging
import time

from basecommons.utils.time_utils import get_current_timestamp

logger = logging.getLogger(__name__)


def format_human_time(duration_ms):
    """
    将毫秒转换为 00:00:00 格式
    :param duration_ms: 毫秒数
    :return: 格式化后的时间字符串
    """
    seconds = duration_ms / 1000
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    seconds = int(seconds % 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"  # 保留3位小数


def format_human_size(size_bytes):
    """
    将字节数转换为可读的文件大小
    :param size_bytes: 字节数
    :return: 格式化后的文件大小字符串
    """
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.2f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.2f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"

def format_large_number(number):
    """
    将大数字转换为万/亿为单位的字符串，保留两位小数
    :param number: 待转换的数字
    :return: 格式化后的字符串（如"776.48万"、"1.23亿"）
    """
    # 如果不是数字，直接返回
    if not isinstance(number, (int, float)):
        return number
    if number < 10000:
        return f"{number}"
    elif number < 100000000:  # 1亿
        return f"{number / 10000:.2f}万"
    else:
        return f"{number / 100000000:.2f}亿"

if __name__ == '__main__':
    start_time = get_current_timestamp()
    time.sleep(1)
    end_time = get_current_timestamp()
    use_time = end_time - start_time
    print(format_human_time(use_time))
    print(format_human_size(1922660))
