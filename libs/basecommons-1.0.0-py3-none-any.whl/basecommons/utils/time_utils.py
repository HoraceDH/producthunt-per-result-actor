#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-06-16 21:18.
# @author Horace
import logging
import time
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


def get_current_time_format() -> str:
    """
    获取当前时间
    :return: 当前时间，yyyy-MM-dd HH:mm:ss
    """
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())


def get_current_timestamp() -> int:
    """
    获取当前时间戳
    :return: 当前时间戳毫秒数
    """
    timestamp = datetime.now().timestamp()
    return int(timestamp * 1000)


def get_current_ns_timestamp() -> int:
    """
    获取当前时间纳秒数
    :return:
    """
    current_ns = time.perf_counter_ns()
    return current_ns


def get_current_date() -> datetime:
    """
    获取当前日期
    :return:
    """
    current_date = datetime.now().date()
    return current_date


def get_current_date_str() -> str:
    """
    获取当前日期字符串
    :return:
    """
    current_date = get_current_date()
    current_date_str = current_date.strftime("%Y-%m-%d")
    return current_date_str


def format_date(date: datetime) -> str:
    """
    格式化日期
    :param date: 日期
    :return: 格式化后的日期字符串
    """
    date_str = date.strftime("%Y-%m-%d")
    return date_str


def format_datetime(date: datetime) -> str:
    """
    格式化日期
    :param date: 日期
    :return: 格式化后的日期字符串
    """
    date_str = date.strftime("%Y-%m-%d %H:%M:%S")
    return date_str


def parse_iso8601_date(date_str: str) -> datetime:
    """
    解析ISO8601格式的日期字符串
    :param date_str: ISO8601格式的日期字符串，例如：2025-08-18T00:00:00Z
    :return: 解析后的日期对象
    """
    return parse_date(date_str, "%Y-%m-%dT%H:%M:%SZ")


def parse_iso8601_s_date(date_str: str) -> datetime:
    """
    解析ISO8601格式的日期字符串
    :param date_str: ISO8601格式的日期字符串，例如：2025-05-11T11:02:40.796Z
    :return: 解析后的日期对象
    """
    return parse_date(date_str, "%Y-%m-%dT%H:%M:%S.%fZ")


def parse_date(date_str: str, date_format: str) -> datetime:
    """
    将时间字符串转换为日期字符串
    :param date_str: 时间字符串
    :param date_format: 时间格式，例如：%Y-%m-%d
    :return: 日期对象
    """
    if date_str is None or len(date_str) == 0:
        return None
    try:
        return datetime.strptime(date_str, date_format)
    except ValueError:
        logger.error(f"parse date failed, date_str: {date_str}, date_format: {date_format}")
        return None


def parse_iso_datetime(time_str: str) -> str:
    """
    将ISO格式的时间字符串转换为datetime对象
    :param time_str: 2025-08-24T00:24:55-07:00 格式的时间字符串
    :return: datetime对象
    """
    if time_str is None or len(time_str) == 0:
        return None
    return datetime.fromisoformat(time_str)

def get_previous_month_day_range(date: datetime) -> tuple[datetime, datetime]:
    """
    获取前一个月的天数范围，例如2025-09-18的日期范围为2025-08-01到2025-08-31

    :return: 日期范围，包含日期的第一天和最后一天
    """
    first_day_of_current_month = date.replace(day=1)
    last_day_of_last_month = first_day_of_current_month - timedelta(days=1)
    first_day_of_last_month = last_day_of_last_month.replace(day=1)

    # 设置时间为起止时间
    first_day_of_last_month = first_day_of_last_month.replace(hour=0, minute=0, second=0, microsecond=0)
    last_day_of_last_month = last_day_of_last_month.replace(hour=23, minute=59, second=59, microsecond=0)
    return first_day_of_last_month, last_day_of_last_month


def get_month_day_range(date: datetime) -> tuple[datetime, datetime]:
    """
    获取指定日期的月份天数范围，例如2025-09-18的日期范围为2025-09-01到2025-09-30
    :param date: 日期
    :return: 日期范围，包含日期的第一天和最后一天
    """
    first_day_of_current_month = date.replace(day=1)
    last_day_of_current_month = first_day_of_current_month.replace(month=date.month + 1) - timedelta(days=1)

    # 设置时间为起止时间
    if isinstance(date, datetime):
        first_day_of_current_month = first_day_of_current_month.replace(hour=0, minute=0, second=0, microsecond=0)
        last_day_of_current_month = last_day_of_current_month.replace(hour=23, minute=59, second=59, microsecond=0)
    return first_day_of_current_month, last_day_of_current_month

def parse_timestamp_to_date(timestamp: int) -> datetime:
    """
    解析时间戳为日期对象，可以是10位时间戳，也可以是13位毫秒级时间戳
    :param timestamp: 时间戳毫秒数
    :return: 日期对象
    """
    if timestamp is None or len(str(timestamp)) == 0:
        return None
    return datetime.fromtimestamp(timestamp)