#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-07-31 18:54.
# @author Horace
import dataclasses
import json
import logging
from datetime import datetime, date
from typing import Any

from basecommons.utils.time_utils import format_datetime

logger = logging.getLogger(__name__)


def to_json_object(json_str: str) -> Any:
    """
    将json字符串转换为json对象
    :param json_str: json字符串
    :return: json对象，如果不是json字符串或者不合法，则返回None
    """
    return to_object(json_str=json_str)


def to_object(json_str: str) -> Any:
    """
    将json字符串转换为json对象
    :param json_str: json字符串
    :return: json对象，如果不是json字符串或者不合法，则返回None
    """
    if json_str is None or json_str.isspace():
        logger.debug(f"to json object failed, json_str is none or empty")
        return None

    try:
        json_object = json.loads(json_str)
        if isinstance(json_object, (dict, list)):
            return json_object

        return None
    except Exception as e:
        logger.debug(f"to json object failed, json_str: {json_str}, error: {e}")
        return None


def default_serializer(obj):
    """
    默认的JSOn序列化方法，需要用 @dataclass 定义类结构
    :param obj: 对象
    :return:
    """

    if obj is None:
        return None

    if hasattr(obj, '__dict__'):  # 处理普通类
        return obj.__dict__
    elif hasattr(obj, '_asdict'):  # 处理namedtuple
        return obj._asdict()
    elif dataclasses.is_dataclass(obj):  # 处理dataclass
        return dataclasses.asdict(obj)
    elif isinstance(obj, (list, tuple)):
        return [default_serializer(item) for item in obj]
    elif isinstance(obj, datetime):
        return format_datetime(obj)
    elif isinstance(obj, date):
        return format_datetime(obj)

    logger.warning(f"Object of type {type(obj).__name__} is not JSON serializable, obj: {obj}")
    return ""
    # raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


def to_json_string(obj: Any) -> str:
    """
    将对象转为json字符串
    :param obj: 待转换的对象
    :return: 转换后的json字符串
    """
    return json.dumps(obj, ensure_ascii=False, default=default_serializer)
