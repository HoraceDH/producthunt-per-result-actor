#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-08-12 18:06.
# @author Horace
import logging
from typing import Any

logger = logging.getLogger(__name__)


def get_list_element(objects: list[Any], index: int, default: Any = None):
    """
    获取列表元素
    :param objects: 列表对象
    :param index: 索引
    :param default: 默认值
    :return: 列表元素
    """
    if objects is None or len(objects) == 0:
        return default

    if index < 0 or index >= len(objects):
        return default

    return objects[index]
