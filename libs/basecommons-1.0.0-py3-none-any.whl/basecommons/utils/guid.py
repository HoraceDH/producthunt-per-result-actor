#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-07-30 16:29.
# @author Horace
import logging
import time

logger = logging.getLogger(__name__)


def generate() -> int:
    """
    生成全局唯一ID，不是通过雪花算法提供，请根据场景谨慎使用
    :return:
    """
    # 获取当前纳秒级时间戳
    current_ns = time.perf_counter_ns()
    return current_ns
