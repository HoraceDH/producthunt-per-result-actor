#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-08-08 17:36.
# @author Horace
import logging
from typing import Any

logger = logging.getLogger(__name__)


def convert_actual_type(data: str) -> Any:
    """
    将数据转换为实际的格式，如果是 "123456"，则会返回 123456，如果是 "cn.horace.demo"，则会返回 "cn.horace.demo"
    :param data: 参数数据，可以是："123456"，"cn.horace.demo"
    :return:
    """
    try:
        # 先尝试转换为整数
        return int(data)
    except ValueError:
        try:
            # 再尝试转换为浮点数
            return float(data)
        except ValueError:
            # 都不是数字则返回原字符串
            return data
