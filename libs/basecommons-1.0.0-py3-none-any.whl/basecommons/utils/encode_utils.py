#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-08-22 10:48.
# @author Horace
import logging
import urllib.parse

logger = logging.getLogger(__name__)


def encode_params(params: str) -> str:
    """
    将参数进行URL方式编码
    :param params: 参数
    :return: 编码后的参数
    """
    return urllib.parse.quote(params)


def decode_params(params: str) -> str:
    """
    将URL方式编码的参数进行解码
    :param params: 编码后的参数
    :return: 解码后的参数
    """
    return urllib.parse.unquote(params)
