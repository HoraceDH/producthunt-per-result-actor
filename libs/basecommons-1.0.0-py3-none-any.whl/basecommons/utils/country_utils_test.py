#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-10-23 17:07.
# @author Horace
import logging

from commons.logger import init_logging

from basecommons.utils import country_utils

init_logging()

logger = logging.getLogger(__name__)

if __name__ == '__main__':
    country_code = 'us'
    cn_name = country_utils.get_country_cn_name(country_code)
    en_name = country_utils.get_country_en_name(country_code)
    cc_tld = country_utils.get_country_cc_tld(country_code)
    logger.info(f"国家代码: {country_code}, 中文名: {cn_name}, 英文名: {en_name}, ccTLD: {cc_tld}")
