#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-08-28 16:51.
# @author Horace
import logging
from datetime import datetime, timedelta

from basecommons.utils.time_utils import parse_date, get_previous_month_day_range, get_month_day_range

logger = logging.getLogger(__name__)
if __name__ == '__main__':
    print(parse_date("2023/05/18", "%Y/%m/%d"))

    start_date, end_date = get_previous_month_day_range(datetime.now() - timedelta(days=1))
    print(start_date, end_date)

    start_date, end_date = get_month_day_range(datetime.now())
    print(start_date, end_date)
