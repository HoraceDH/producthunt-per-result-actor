#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-11-08 23:25.
# @author Horace
import asyncio
import logging

from playwright.async_api import async_playwright, APIRequestContext

from basecommons.logger import init_logging
from basecommons.utils.encode_utils import encode_params
from basecommons.utils.json_utils import to_json_string

logger = logging.getLogger(__name__)
init_logging()

def get_headers() -> dict:
    return {
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "accept-language": "zh-CN,zh;q=0.9,ja;q=0.8,en;q=0.7",
        "cache-control": "max-age=0",
        "cookie": "_ga=GA1.1.1009772560.1762068987; ajs_anonymous_id=22d7f6ee-bbf0-4022-a681-00d46e3ac58d; visitor_id=a3db1075-40f0-43f4-9b57-9ea9f6b0740a; track_code=7f370184d0; g_state={\"i_l\":0,\"i_ll\":1762619354640,\"i_b\":\"GxCd5BhPGiBR4qOmCYaqMxEEbl+kdhPXOscovgJ+1fw\"}; __cf_bm=Hb3OXvRpXP4nEhP_C9ztxeuhww.CZ6vG9H.iebehAxc-1762671781-1.0.1.1-U.ZA6nSP2svAcEm.LA.uV01J9NRxohpxCTgP8O7I6ncVsp01v135ygFklCjcVt7wUda.5lZ89NRkqSNQ9Dqpc7KjmQnf5ssO1S_XjgBzhvE; first_visit=1762671792; first_referer=https://www.producthunt.com/?__cf_chl_tk=4.QYAy2foAZO517P2khmi9Zv03Aw2aRbMRVzUNzOsGY-1762671781-1.0.1.1-AgDKxDfpiNtQDx1Vybyjsfe14fKW0N4RiOBnIrYLDiU; cf_clearance=S8QflXXcVKUl6t0UE19JcaEW2bCo00F8aGBnSfC2B7M-1762671793-1.2.1.1-01emtPmUX4qeLT3AZZGiCTOzAg8.2QLvCQbY7fLK7JIqOWbxSjusLGeRpuH0YHss9MdAFOyWSyWQGu6PCpubFtnI23R68OHNqCdx.nNZI89crjh_oLv4YxLNUkJxtnoua43Jc0LQdS8sAbY38x5RmS2YtJg_ZOMk7Uf2XGQXF4MEVeCWxS4WQ95g4yUCBnuwnJQoCg1ksu20uW.23ifPFPxGBdoStFPDOt0ngO7Eb1M.A6DaDCaxDhAJj0SxHn74; _ga_WZ46833KH9=GS2.1.s1762671792$o14$g1$t1762671803$j49$l0$h0; producthunt.reset=1.0; csrf_token=Z9csJzvE-Iu8kAxB65dvEdP5jbGeutmjvPwW7IF7ZkV2B9TbX9o0MhhF5kSS6L7ma2oVoA5c-HIruCFHiCnR_g; _producthunt_session_production=PBEe0%2BVt1%2B6bSEb7TFYepT%2Ftj34ZaTKR8qVEGrJiX6dGotdwle5zQrzOUt1VI3dPysjI9ckXgl69nnV4yC2xtEgYCINuqAHltLDIID5Dk%2FVYENJ9fdK9u7hT7el9SnpI5%2F%2FLx7k8nEaVjhFJf2A0vHfx1z5GqcIkejPhilJvv%2BG4rq%2FHceYPudTHTz3NrRV%2BKJrfNdI9xREhYU54NX9MHHTUdbH8eGVymrNb%2F40nHlvIBaVKM5NaTd1aw0dIPa7CsFQ4Y8OTZTzjChr4ogA%2FGgJ9XxjpXmFpsysXUXanFmQKU%2FvWdYOcH1IIehWz1EyYS8Vivn1iIFVUNQUCsg%3D%3D--r8QjXXvRMaTJfQsX--LiSS3Z%2BsAASRa8iPXFBxUw%3D%3D; _dd_s=aid=2de3bbce-64af-43d3-bd9c-a9eb163eea90&rum=2&id=14ab0f60-f009-4b78-a7c7-46154f565c11&created=1762671792727&expire=1762672720602",
        "priority": "u=0, i",
        "referer": "https://www.producthunt.com/?__cf_chl_tk=4.QYAy2foAZO517P2khmi9Zv03Aw2aRbMRVzUNzOsGY-1762671781-1.0.1.1-AgDKxDfpiNtQDx1Vybyjsfe14fKW0N4RiOBnIrYLDiU",
        "sec-ch-ua": "\"Chromium\";v=\"142\", \"Google Chrome\";v=\"142\", \"Not_A Brand\";v=\"99\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"macOS\"",
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "same-origin",
        "sec-fetch-user": "?1",
        "upgrade-insecure-requests": "1",
        "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36"
    }

async def send_request_in_playwright(request: "APIRequestContext"):
    variables = encode_params(
        f'{{"commentsListSubjectThreadsCursor":"","commentsListSubjectThreadsPage":null,"commentsThreadRepliesCursor":"","order":"DATE","slug":"ai-context-flow","includeThreadForCommentId":null,"commentsListSubjectThreadsLimit":{10},"commentsListSubjectFilter":null,"excludeThreadForCommentId":null}}')
    extensions = encode_params(f'{{"persistedQuery":{{"version":1,"sha256Hash":"3c55cdfbdb7e2de4089fe7143bb75f1f4118ba83547755d893c0e44be60209e4"}}}}')
    params = f'operationName=PostPageComments&variables={variables}&extensions={extensions}'
    url = f"https://www.producthunt.com/frontend/graphql?{params}"
    response = await request.get(url=url, headers=get_headers())
    logger.info(f"in response status: {response.status}, headers: {to_json_string(response.headers)}, body: {await response.text()}")

    pass

async def get_response_headers(url: str = "https://www.producthunt.com/leaderboard/daily/2025/11/8/all"):
    async with async_playwright() as playwright:
        browser = await playwright.chromium.launch(headless=True)
        context = await browser.new_context(no_viewport=True, viewport={"width": 1920, "height": 1080}, extra_http_headers=get_headers())
        page = await context.new_page()

        # 监听 request 事件
        async def handle_request(request):
            if "/all" in request.url or "https://www.producthunt.com/frontend/graphql" in request.url:
                logger.info(f"handle request, url: {request.url}, headers: {to_json_string(request.headers)}")

        page.on("request", handle_request)

        # 监听 response 事件
        async def handle_response(response):
            if "/all" in response.url or "https://www.producthunt.com/frontend/graphql" in response.url:
                await send_request_in_playwright(context.request)

                # 检查是否为重定向响应（3xx状态码）
                if 300 <= response.status < 400:
                    logger.info(f"handle redirect response, url: {response.url}, status: {response.status}, headers: {to_json_string(response.headers)}")
                else:
                    try:
                        response_text = await response.text()
                        logger.info(f"handle response, url: {response.url}, status: {response.status}, text: {response_text}")
                    except Exception as e:
                        logger.warning(f"failed to get response text for {response.url}, status: {response.status}, error: {e}")

        page.on("response", handle_response)

        await page.goto(url)
        # 等待几秒让所有请求完成
        await page.wait_for_timeout(000)


if __name__ == '__main__':
    asyncio.run(get_response_headers())
