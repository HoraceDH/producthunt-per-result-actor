#!/usr/bin/python
# -*- coding:utf-8 -*-
# Created in 2025-06-15 22:52.
# @author Horace
import logging
import os

from sqlalchemy import create_engine, Column, String, DateTime, BIGINT
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.pool import QueuePool

logger = logging.getLogger(__name__)

G_ENV_DATABASE_URL = os.environ.get("DATABASE_URL", "mysql+pymysql://template_user:template_pass@192.168.41.31:3306/template?charset=utf8mb4")
G_ENV_DATABASE_POOL_SIZE = int(os.environ.get("DATABASE_POOL_SIZE", 5))
G_ENV_DATABASE_MAX_OVERFLOW = int(os.environ.get("DATABASE_MAX_OVERFLOW", 10))
G_ENV_DATABASE_POOL_PRE_PING = os.environ.get("DATABASE_POOL_PRE_PING", "true").lower() == "true"
G_ENV_DATABASE_POOL_RECYCLE = int(os.environ.get("DATABASE_POOL_RECYCLE", 300))

# 数据库配置
engine = create_engine(
    G_ENV_DATABASE_URL,
    poolclass=QueuePool,  # 使用连接池
    pool_size=G_ENV_DATABASE_POOL_SIZE,  # 连接池中保持的连接数
    max_overflow=G_ENV_DATABASE_MAX_OVERFLOW,  # 超出pool_size后允许创建的连接数
    pool_pre_ping=G_ENV_DATABASE_POOL_PRE_PING,  # 执行前检查连接是否有效
    pool_recycle=G_ENV_DATABASE_POOL_RECYCLE  # 连接回收时间(秒)
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
BaseModel = declarative_base()


class Base(BaseModel):
    """
    基础模型类
    """
    __abstract__ = True

    def model_to_dict(self):
        """
        将对象转换为字典格式
        :return: 字典格式的对象
        """
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}


def init():
    """
    初始化数据库连接
    :return:
    """
    try:
        # 测试连接是否成功
        with engine.connect() as conn:
            logger.info(f"database connection initialized successfully, url: {conn.engine.url}")
    except Exception as e:
        logger.error(f"failed to initialize database connection: {e}")
        raise
